# QuizMaster ProGuard rules
-keep class com.quizmaster.models.** { *; }
