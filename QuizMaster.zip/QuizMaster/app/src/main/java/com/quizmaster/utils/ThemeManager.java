package com.quizmaster.utils;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.ImageView;
import androidx.cardview.widget.CardView;

public class ThemeManager {

    public static final String THEME_DARK   = "Dark Purple";
    public static final String THEME_OCEAN  = "Ocean";
    public static final String THEME_AMOLED = "Amoled Black";

    private static final String PREFS = "qm_theme";
    private static ThemeManager instance;
    private SharedPreferences prefs;

    public static class Theme {
        public final String name, emoji;
        public final int primary, primaryDark, accent;
        public final int bg, surface, surface2, input, border;
        public final int textPrimary, textSecondary, textHint;
        public final int correct, wrong, warn;
        public final int cardBanner, btnText;

        public Theme(String name, String emoji,
                     int primary, int primaryDark, int accent,
                     int bg, int surface, int surface2, int input, int border,
                     int textPrimary, int textSecondary, int textHint,
                     int correct, int wrong, int warn,
                     int cardBanner, int btnText) {
            this.name=name; this.emoji=emoji;
            this.primary=primary; this.primaryDark=primaryDark; this.accent=accent;
            this.bg=bg; this.surface=surface; this.surface2=surface2;
            this.input=input; this.border=border;
            this.textPrimary=textPrimary; this.textSecondary=textSecondary; this.textHint=textHint;
            this.correct=correct; this.wrong=wrong; this.warn=warn;
            this.cardBanner=cardBanner; this.btnText=btnText;
        }
    }

    private static final Theme DARK = new Theme(
        THEME_DARK, "🌌",
        Color.parseColor("#6C63FF"), Color.parseColor("#4A3FCC"), Color.parseColor("#FF6584"),
        Color.parseColor("#0F0E17"), Color.parseColor("#1A1A2E"), Color.parseColor("#16213E"),
        Color.parseColor("#252545"), Color.parseColor("#3A3A5C"),
        Color.WHITE, Color.parseColor("#B0B0CC"), Color.parseColor("#6B6B8A"),
        Color.parseColor("#00E5A0"), Color.parseColor("#FF4757"), Color.parseColor("#FFB347"),
        Color.parseColor("#6C63FF"), Color.parseColor("#6C63FF")
    );

    private static final Theme OCEAN = new Theme(
        THEME_OCEAN, "🌊",
        Color.parseColor("#0096C7"), Color.parseColor("#0077B6"), Color.parseColor("#48CAE4"),
        Color.parseColor("#03045E"), Color.parseColor("#023E8A"), Color.parseColor("#0077B6"),
        Color.parseColor("#02427A"), Color.parseColor("#0096C7"),
        Color.WHITE, Color.parseColor("#90E0EF"), Color.parseColor("#48CAE4"),
        Color.parseColor("#00F5D4"), Color.parseColor("#EF233C"), Color.parseColor("#FFD166"),
        Color.parseColor("#0096C7"), Color.parseColor("#03045E")
    );

    private static final Theme AMOLED = new Theme(
        THEME_AMOLED, "⬛",
        Color.parseColor("#BB86FC"), Color.parseColor("#985EFF"), Color.parseColor("#03DAC6"),
        Color.BLACK, Color.parseColor("#121212"), Color.parseColor("#1E1E1E"),
        Color.parseColor("#1A1A1A"), Color.parseColor("#2C2C2C"),
        Color.WHITE, Color.parseColor("#BBBBBB"), Color.parseColor("#666666"),
        Color.parseColor("#03DAC6"), Color.parseColor("#CF6679"), Color.parseColor("#FFAB40"),
        Color.parseColor("#BB86FC"), Color.BLACK
    );

    public static ThemeManager getInstance() {
        if (instance == null) instance = new ThemeManager();
        return instance;
    }

    public void init(Context ctx) {
        prefs = ctx.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public void setTheme(String name) {
        if (prefs != null) prefs.edit().putString("theme", name).apply();
    }

    public String getThemeName() {
        return prefs != null ? prefs.getString("theme", THEME_DARK) : THEME_DARK;
    }

    public Theme getTheme() {
        switch (getThemeName()) {
            case THEME_OCEAN:  return OCEAN;
            case THEME_AMOLED: return AMOLED;
            default:           return DARK;
        }
    }

    public Theme getThemeByName(String name) {
        switch (name) {
            case THEME_OCEAN:  return OCEAN;
            case THEME_AMOLED: return AMOLED;
            default:           return DARK;
        }
    }

    /** Apply theme to an activity — sets window bg + traverses all views */
    public void apply(Activity activity) {
        Theme t = getTheme();
        // Window background
        activity.getWindow().getDecorView().setBackgroundColor(t.bg);
        // Apply to all views
        applyToView(activity.getWindow().getDecorView(), t);
    }

    private void applyToView(View view, Theme t) {
        if (view == null) return;

        // Tag-based theming — views tagged with theme keys get specific colors
        Object tag = view.getTag();
        if (tag instanceof String) {
            String s = (String) tag;
            switch (s) {
                case "bg":       view.setBackgroundColor(t.bg); break;
                case "surface":  view.setBackgroundColor(t.surface); break;
                case "surface2": view.setBackgroundColor(t.surface2); break;
                case "primary":  view.setBackgroundColor(t.primary); break;
                case "input":    view.setBackgroundColor(t.input); break;
            }
        }

        // CardViews
        if (view instanceof CardView) {
            ((CardView) view).setCardBackgroundColor(t.surface);
        }

        // TextViews
        if (view instanceof TextView && !(view instanceof android.widget.Button)) {
            // Don't override button colors
            Object tvTag = view.getTag(android.R.id.text1);
            if (tvTag instanceof String) {
                String ts = (String) tvTag;
                switch (ts) {
                    case "primary":   ((TextView)view).setTextColor(t.textPrimary); break;
                    case "secondary": ((TextView)view).setTextColor(t.textSecondary); break;
                    case "accent":    ((TextView)view).setTextColor(t.primary); break;
                }
            }
        }

        // Recurse into ViewGroups
        if (view instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) view;
            for (int i = 0; i < vg.getChildCount(); i++) {
                applyToView(vg.getChildAt(i), t);
            }
        }
    }

    /** Quick apply — just set window background color (fast, no full traversal) */
    public void applyToActivity(Activity activity) {
        Theme t = getTheme();
        activity.getWindow().getDecorView().setBackgroundColor(t.bg);
    }

    public static Theme[] getAllThemes() {
        return new Theme[]{DARK, OCEAN, AMOLED};
    }
}