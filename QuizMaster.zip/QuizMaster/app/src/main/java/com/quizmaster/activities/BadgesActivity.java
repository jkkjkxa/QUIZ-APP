package com.quizmaster.activities;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.quizmaster.R;
import com.quizmaster.utils.ThemeManager;
import com.quizmaster.adapters.BadgeAdapter;
import com.quizmaster.models.Badge;
import com.quizmaster.utils.LocalDataManager;
import java.util.List;

public class BadgesActivity extends AppCompatActivity {
    @Override
    @SuppressWarnings({"deprecation", "unchecked"})
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ThemeManager.getInstance().init(this);
        setContentView(R.layout.activity_badges);
        ThemeManager.getInstance().applyToActivity(this);
        LocalDataManager.getInstance().init(this);

        ((ImageView) findViewById(R.id.ivBack)).setOnClickListener(v -> finish());

        List<Badge> badges = LocalDataManager.getInstance().getAllBadges();
        long unlocked = badges.stream().filter(b -> b.unlocked).count();

        ((TextView) findViewById(R.id.tvUnlocked)).setText(unlocked + "/" + badges.size() + " unlocked");

        RecyclerView rv = findViewById(R.id.rvBadges);
        rv.setLayoutManager(new GridLayoutManager(this, 3));
        rv.setAdapter(new BadgeAdapter(badges));
    }
}