package com.quizmaster.activities;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.quizmaster.R;
import com.quizmaster.utils.ThemeManager;
import com.quizmaster.adapters.CategoryAdapter;
import com.quizmaster.models.Category;
import java.util.Arrays;
import java.util.List;

public class CategoryActivity extends AppCompatActivity {
    @Override
    @SuppressWarnings({"deprecation", "unchecked"})
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ThemeManager.getInstance().init(this);
        setContentView(R.layout.activity_category);
        ThemeManager.getInstance().applyToActivity(this);

        ImageView ivBack = findViewById(R.id.ivBack);
        ivBack.setOnClickListener(v -> finish());

        RecyclerView rv = findViewById(R.id.rvCategories);
        rv.setLayoutManager(new LinearLayoutManager(this));

        List<Category> cats = getCategories();
        rv.setAdapter(new CategoryAdapter(cats, cat -> {
            Intent i = new Intent(this, QuizSetupActivity.class);
            i.putExtra("cat_name", cat.name);
            i.putExtra("cat_emoji", cat.emoji);
            i.putExtra("cat_id", cat.apiId);
            startActivity(i);
        }));
    }

    private List<Category> getCategories() {
        return Arrays.asList(
            new Category("Science", "🔬", "Biology, Physics, Chemistry & more",    "17", Color.parseColor("#00B4D8")),
            new Category("History", "🏛️", "Ancient to modern world history",        "23", Color.parseColor("#F4A261")),
            new Category("Sports",  "⚽", "Football, Basketball, Olympics & more",  "21", Color.parseColor("#2EC4B6")),
            new Category("Entertainment","🎬","Movies, TV shows & celebrities",     "11", Color.parseColor("#E63946")),
            new Category("Geography","🌍","Countries, capitals & landmarks",        "22", Color.parseColor("#57CC99")),
            new Category("Technology","💻","Computers, internet & gadgets",         "18", Color.parseColor("#9D4EDD")),
            new Category("Mathematics","📐","Numbers, algebra & brain teasers",     "19", Color.parseColor("#F72585")),
            new Category("Art & Literature","🎨","Books, paintings & culture",      "25", Color.parseColor("#FB8500")),
            new Category("Music",   "🎵","Bands, songs & music theory",            "12", Color.parseColor("#48CAE4")),
            new Category("Nature",  "🌿","Animals, plants & ecology",              "27", Color.parseColor("#52B788")),
            new Category("General Knowledge","💡","A little bit of everything",     "9",  Color.parseColor("#A8DADC")),
            new Category("Vehicles","🚗","Cars, planes & transportation",           "28", Color.parseColor("#E9C46A"))
        );
    }
}