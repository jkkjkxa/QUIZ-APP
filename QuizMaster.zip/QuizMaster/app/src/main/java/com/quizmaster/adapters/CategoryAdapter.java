package com.quizmaster.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.quizmaster.R;
import com.quizmaster.models.Category;
import java.util.List;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.VH> {
    private final List<Category> list;
    private final OnCategoryClick listener;

    public interface OnCategoryClick { void onClick(Category c); }

    public CategoryAdapter(List<Category> list, OnCategoryClick listener) {
        this.list = list;
        this.listener = listener;
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_category, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        Category c = list.get(pos);
        h.emoji.setText(c.emoji);
        h.name.setText(c.name);
        h.desc.setText(c.description);
        h.itemView.setOnClickListener(v -> listener.onClick(c));
    }

    @Override public int getItemCount() { return list.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView emoji, name, desc;
        VH(View v) {
            super(v);
            emoji = v.findViewById(R.id.tvEmoji);
            name  = v.findViewById(R.id.tvName);
            desc  = v.findViewById(R.id.tvDesc);
        }
    }
}