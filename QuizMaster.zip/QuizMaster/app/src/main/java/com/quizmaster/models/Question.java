package com.quizmaster.models;

import java.io.Serializable;
import java.util.List;

public class Question implements Serializable {
    public String category, difficulty, question, correct_answer;
    public List<String> incorrect_answers;
}