package com.quizmaster.models;

public class CategoryStat {
    public String category, emoji;
    public int totalQuestions, correctAnswers;
    public float accuracy;

    public CategoryStat(String category, String emoji) {
        this.category = category; this.emoji = emoji;
    }
}