package com.quizmaster.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.quizmaster.R;
import com.quizmaster.utils.ThemeManager;

public class QuizSetupActivity extends AppCompatActivity {
    private int questionCount = 5;
    private String difficulty  = "easy";
    private String catName, catEmoji, catId;

    private android.widget.TextView btn5, btn10, btn15, btnEasy, btnMedium, btnHard;

    @Override
    @SuppressWarnings({"deprecation", "unchecked"})
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ThemeManager.getInstance().init(this);
        setContentView(R.layout.activity_quiz_setup);
        ThemeManager.getInstance().applyToActivity(this);

        catName  = getIntent().getStringExtra("cat_name");
        catEmoji = getIntent().getStringExtra("cat_emoji");
        catId    = getIntent().getStringExtra("cat_id");

        ImageView ivBack = findViewById(R.id.ivBack);
        ivBack.setOnClickListener(v -> finish());

        // Category display
        ((TextView) findViewById(R.id.tvCategoryEmoji)).setText(catEmoji);
        ((TextView) findViewById(R.id.tvCategoryName)).setText(catName);

        // Question count buttons
        btn5  = findViewById(R.id.btn5);
        btn10 = findViewById(R.id.btn10);
        btn15 = findViewById(R.id.btn15);
        btn5.setOnClickListener(v  -> setCount(5));
        btn10.setOnClickListener(v -> setCount(10));
        btn15.setOnClickListener(v -> setCount(15));

        // SeekBar
        SeekBar seek  = findViewById(R.id.seekBarQuestions);
        TextView tvCount = findViewById(R.id.tvQuestionCount);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean b) {
                questionCount = v;
                tvCount.setText(v + " Questions");
                clearCountButtons();
                if (v == 5)       highlightCount(btn5);
                else if (v == 10) highlightCount(btn10);
                else if (v == 15) highlightCount(btn15);
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });

        // Difficulty
        btnEasy   = findViewById(R.id.btnEasy);
        btnMedium = findViewById(R.id.btnMedium);
        btnHard   = findViewById(R.id.btnHard);
        btnEasy.setOnClickListener(v   -> setDifficulty("easy",   btnEasy,   btnMedium, btnHard));
        btnMedium.setOnClickListener(v -> setDifficulty("medium", btnMedium, btnEasy,   btnHard));
        btnHard.setOnClickListener(v   -> setDifficulty("hard",   btnHard,   btnEasy,   btnMedium));

        // Default state
        highlightCount(btn5);
        btnEasy.setBackgroundResource(R.drawable.bg_difficulty_easy);
        btnEasy.setTextColor(getColor(R.color.correct_green));

        // Begin
        android.widget.TextView btnBegin = (android.widget.TextView) findViewById(R.id.btnBegin);
        btnBegin.setOnClickListener(v -> {
            Intent i = new Intent(this, QuizActivity.class);
            i.putExtra("count", questionCount);
            i.putExtra("difficulty", difficulty);
            i.putExtra("cat_name", catName);
            i.putExtra("cat_emoji", catEmoji);
            i.putExtra("cat_id", catId);
            startActivity(i);
        });
    }

    private void setCount(int n) {
        questionCount = n;
        clearCountButtons();
        ((SeekBar) findViewById(R.id.seekBarQuestions)).setProgress(n);
        ((TextView) findViewById(R.id.tvQuestionCount)).setText(n + " Questions");
        android.widget.TextView b = n == 5 ? btn5 : n == 10 ? btn10 : btn15;
        highlightCount(b);
    }

    private void clearCountButtons() {
        for (android.widget.TextView b : new android.widget.TextView[]{btn5, btn10, btn15}) {
            b.setBackgroundResource(R.drawable.bg_option_normal);
            b.setTextColor(getColor(R.color.text_secondary));
        }
    }

    private void highlightCount(android.widget.TextView b) {
        b.setBackgroundResource(R.drawable.bg_option_selected);
        b.setTextColor(getColor(R.color.text_primary));
    }

    private void setDifficulty(String d, android.widget.TextView active, android.widget.TextView... others) {
        difficulty = d;
        int bg = d.equals("easy") ? R.drawable.bg_difficulty_easy :
                 d.equals("medium") ? R.drawable.bg_difficulty_medium : R.drawable.bg_difficulty_hard;
        int color = d.equals("easy") ? R.color.correct_green :
                    d.equals("medium") ? R.color.warning_yellow : R.color.wrong_red;
        active.setBackgroundResource(bg);
        active.setTextColor(getColor(color));
        for (android.widget.TextView b : others) {
            b.setBackgroundResource(R.drawable.bg_option_normal);
            b.setTextColor(getColor(R.color.text_secondary));
        }
    }
}