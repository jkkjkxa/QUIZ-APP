package com.quizmaster.adapters;

import android.view.*;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.quizmaster.R;
import com.quizmaster.models.BookmarkedQuestion;
import java.util.List;

public class BookmarkAdapter extends RecyclerView.Adapter<BookmarkAdapter.VH> {
    private final List<BookmarkedQuestion> list;
    private final OnRemove onRemove;
    public interface OnRemove { void remove(int pos, BookmarkedQuestion q); }

    public BookmarkAdapter(List<BookmarkedQuestion> list, OnRemove onRemove) {
        this.list = list; this.onRemove = onRemove;
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup p, int t) {
        View v = LayoutInflater.from(p.getContext()).inflate(R.layout.item_bookmark, p, false);
        return new VH(v);
    }

    @Override public void onBindViewHolder(@NonNull VH h, int pos) {
        BookmarkedQuestion q = list.get(pos);
        h.tvQuestion.setText(q.question);
        h.tvAnswer.setText("✓ " + q.correctAnswer);
        h.tvMeta.setText(q.category + " · " + q.difficulty);
        h.tvRemove.setOnClickListener(v -> onRemove.remove(pos, q));
    }

    @Override public int getItemCount() { return list.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvQuestion, tvAnswer, tvMeta, tvRemove;
        VH(View v) {
            super(v);
            tvQuestion = v.findViewById(R.id.tvBookmarkQuestion);
            tvAnswer   = v.findViewById(R.id.tvBookmarkAnswer);
            tvMeta     = v.findViewById(R.id.tvBookmarkMeta);
            tvRemove   = v.findViewById(R.id.tvBookmarkRemove);
        }
    }
}