package com.quizmaster.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.quizmaster.R;
import com.quizmaster.utils.ThemeManager;
import com.quizmaster.adapters.BookmarkAdapter;
import com.quizmaster.models.BookmarkedQuestion;
import com.quizmaster.utils.LocalDataManager;
import java.util.List;

public class BookmarksActivity extends AppCompatActivity {
    private BookmarkAdapter adapter;
    private List<BookmarkedQuestion> list;
    private TextView tvEmpty;

    @Override
    @SuppressWarnings({"deprecation", "unchecked"})
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ThemeManager.getInstance().init(this);
        setContentView(R.layout.activity_bookmarks);
        ThemeManager.getInstance().applyToActivity(this);
        LocalDataManager.getInstance().init(this);

        ((ImageView) findViewById(R.id.ivBack)).setOnClickListener(v -> finish());
        tvEmpty = findViewById(R.id.tvEmpty);

        RecyclerView rv = findViewById(R.id.rvBookmarks);
        rv.setLayoutManager(new LinearLayoutManager(this));
        list = LocalDataManager.getInstance().getBookmarks();
        adapter = new BookmarkAdapter(list, (pos, q) -> {
            LocalDataManager.getInstance().removeBookmark(q.question);
            list.remove(pos);
            adapter.notifyItemRemoved(pos);
            updateEmpty();
        });
        rv.setAdapter(adapter);
        updateEmpty();
    }

    private void updateEmpty() {
        tvEmpty.setVisibility(list.isEmpty() ? View.VISIBLE : View.GONE);
    }
}