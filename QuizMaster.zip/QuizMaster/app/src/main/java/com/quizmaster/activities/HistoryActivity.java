package com.quizmaster.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.quizmaster.R;
import com.quizmaster.utils.ThemeManager;
import com.quizmaster.adapters.HistoryAdapter;
import com.quizmaster.models.QuizHistory;
import com.quizmaster.utils.LocalDataManager;
import java.util.List;

public class HistoryActivity extends AppCompatActivity {
    private HistoryAdapter adapter;
    private List<QuizHistory> historyList;
    private TextView tvEmpty;

    @Override
    @SuppressWarnings({"deprecation", "unchecked"})
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ThemeManager.getInstance().init(this);
        setContentView(R.layout.activity_history);
        ThemeManager.getInstance().applyToActivity(this);
        LocalDataManager.getInstance().init(this);

        ((ImageView) findViewById(R.id.ivBack)).setOnClickListener(v -> finish());
        tvEmpty = findViewById(R.id.tvEmpty);
        RecyclerView rv = findViewById(R.id.rvHistory);
        rv.setLayoutManager(new LinearLayoutManager(this));

        historyList = LocalDataManager.getInstance().getHistory();
        adapter = new HistoryAdapter(historyList);
        rv.setAdapter(adapter);
        updateEmpty();

        findViewById(R.id.tvClear).setOnClickListener(v -> {
            LocalDataManager.getInstance().clearHistory();
            historyList.clear();
            adapter.notifyDataSetChanged();
            updateEmpty();
        });
    }

    private void updateEmpty() {
        tvEmpty.setVisibility(historyList.isEmpty() ? View.VISIBLE : View.GONE);
    }
}