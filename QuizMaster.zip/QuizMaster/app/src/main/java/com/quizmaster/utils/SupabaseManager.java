package com.quizmaster.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.quizmaster.models.LeaderboardEntry;
import com.quizmaster.models.UserProfile;
import okhttp3.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Supabase REST API manager.
 * SETUP: Replace SUPABASE_URL and SUPABASE_ANON_KEY with your project values.
 */
public class SupabaseManager {

    // ──────────────────────────────────────────────────────────────────────────
    // 🔑  REPLACE THESE WITH YOUR SUPABASE PROJECT CREDENTIALS
    private static final String SUPABASE_URL  = "https://iqgymdyqvirubmnhheei.supabase.co";
    private static final String SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlxZ3ltZHlxdmlydWJtbmhoZWVpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzkyODExODMsImV4cCI6MjA5NDg1NzE4M30.62UR18VECC5KmBNLcfHW-q4OHjmaLobCxDYHPztd1ak";
    // ──────────────────────────────────────────────────────────────────────────

    private static final String PREFS = "quizmaster_prefs";
    private static SupabaseManager instance;
    private final OkHttpClient http;
    private final Gson gson = new Gson();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;

    public interface AuthCallback {
        void onSuccess(UserProfile user);
        void onError(String message);
    }

    public interface VoidCallback {
        void onSuccess();
        void onError(String message);
    }

    public interface LeaderboardCallback {
        void onSuccess(List<LeaderboardEntry> entries);
        void onError(String message);
    }

    private SupabaseManager() {
        http = new OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build();
    }

    public static SupabaseManager getInstance() {
        if (instance == null) instance = new SupabaseManager();
        return instance;
    }

    public void init(Context ctx) {
        prefs = ctx.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    // ── Session ───────────────────────────────────────────────────────────────
    public void saveSession(String token, UserProfile user) {
        prefs.edit()
            .putString("access_token", token)
            .putString("user_id", user.id)
            .putString("username", user.username)
            .putString("email", user.email)
            .apply();
    }

    public boolean isLoggedIn() {
        return prefs != null && prefs.getString("access_token", null) != null;
    }

    public UserProfile getLocalUser() {
        if (prefs == null) return null;
        String id = prefs.getString("user_id", null);
        if (id == null) return null;
        UserProfile u = new UserProfile();
        u.id = id;
        u.username = prefs.getString("username", "Player");
        u.email = prefs.getString("email", "");
        u.totalQuizzes = prefs.getInt("total_quizzes", 0);
        u.bestScore = prefs.getInt("best_score", 0);
        u.avgAccuracy = prefs.getFloat("avg_accuracy", 0);
        u.streak = prefs.getInt("streak", 0);
        return u;
    }

    public void logout() {
        if (prefs != null) prefs.edit().clear().apply();
    }

    private String getToken() {
        return prefs != null ? prefs.getString("access_token", "") : "";
    }

    // ── Auth: Register ────────────────────────────────────────────────────────
    public void register(String email, String password, String username, AuthCallback cb) {
        new Thread(() -> {
            try {
                JsonObject body = new JsonObject();
                body.addProperty("email", email);
                body.addProperty("password", password);
                JsonObject meta = new JsonObject();
                meta.addProperty("username", username);
                body.add("data", meta);

                Request req = new Request.Builder()
                    .url(SUPABASE_URL + "/auth/v1/signup")
                    .post(RequestBody.create(body.toString(), MediaType.get("application/json")))
                    .addHeader("apikey", SUPABASE_ANON_KEY)
                    .addHeader("Content-Type", "application/json")
                    .build();

                try (Response res = http.newCall(req).execute()) {
                    String json = res.body().string();
                    JsonObject obj = gson.fromJson(json, JsonObject.class);
                    if (!res.isSuccessful() || obj.has("error")) {
                        String msg = obj.has("msg") ? obj.get("msg").getAsString() :
                                     obj.has("error_description") ? obj.get("error_description").getAsString() : "Registration failed";
                        mainHandler.post(() -> cb.onError(msg));
                        return;
                    }
                    String token = obj.get("access_token").getAsString();
                    JsonObject userObj = obj.getAsJsonObject("user");
                    String uid = userObj.get("id").getAsString();
                    UserProfile user = new UserProfile(uid, username, email);
                    saveSession(token, user);
                    // Insert profile row
                    insertProfile(uid, username, email, token);
                    mainHandler.post(() -> cb.onSuccess(user));
                }
            } catch (Exception e) {
                mainHandler.post(() -> cb.onError("Network error: " + e.getMessage()));
            }
        }).start();
    }

    // ── Auth: Login ───────────────────────────────────────────────────────────
    public void login(String email, String password, AuthCallback cb) {
        new Thread(() -> {
            try {
                JsonObject body = new JsonObject();
                body.addProperty("email", email);
                body.addProperty("password", password);

                Request req = new Request.Builder()
                    .url(SUPABASE_URL + "/auth/v1/token?grant_type=password")
                    .post(RequestBody.create(body.toString(), MediaType.get("application/json")))
                    .addHeader("apikey", SUPABASE_ANON_KEY)
                    .addHeader("Content-Type", "application/json")
                    .build();

                try (Response res = http.newCall(req).execute()) {
                    String json = res.body().string();
                    JsonObject obj = gson.fromJson(json, JsonObject.class);
                    if (!res.isSuccessful() || obj.has("error")) {
                        String msg = obj.has("error_description") ? obj.get("error_description").getAsString() : "Login failed";
                        mainHandler.post(() -> cb.onError(msg));
                        return;
                    }
                    String token = obj.get("access_token").getAsString();
                    JsonObject userObj = obj.getAsJsonObject("user");
                    String uid = userObj.get("id").getAsString();
                    // Fetch profile
                    fetchAndSaveProfile(uid, email, token, cb);
                }
            } catch (Exception e) {
                mainHandler.post(() -> cb.onError("Network error: " + e.getMessage()));
            }
        }).start();
    }

    private void insertProfile(String uid, String username, String email, String token) {
        try {
            JsonObject body = new JsonObject();
            body.addProperty("id", uid);
            body.addProperty("username", username);
            body.addProperty("email", email);
            body.addProperty("total_quizzes", 0);
            body.addProperty("best_score", 0);
            body.addProperty("avg_accuracy", 0.0);
            body.addProperty("streak", 0);

            Request req = new Request.Builder()
                .url(SUPABASE_URL + "/rest/v1/profiles")
                .post(RequestBody.create(body.toString(), MediaType.get("application/json")))
                .addHeader("apikey", SUPABASE_ANON_KEY)
                .addHeader("Authorization", "Bearer " + token)
                .addHeader("Content-Type", "application/json")
                .addHeader("Prefer", "return=minimal")
                .build();
            http.newCall(req).execute().close();
        } catch (Exception ignored) {}
    }

    private void fetchAndSaveProfile(String uid, String email, String token, AuthCallback cb) {
        try {
            Request req = new Request.Builder()
                .url(SUPABASE_URL + "/rest/v1/profiles?id=eq." + uid + "&select=*")
                .get()
                .addHeader("apikey", SUPABASE_ANON_KEY)
                .addHeader("Authorization", "Bearer " + token)
                .build();

            try (Response res = http.newCall(req).execute()) {
                String json = res.body().string();
                JsonArray arr = gson.fromJson(json, JsonArray.class);
                UserProfile user;
                if (arr != null && arr.size() > 0) {
                    JsonObject p = arr.get(0).getAsJsonObject();
                    user = new UserProfile(uid,
                        p.has("username") ? p.get("username").getAsString() : "Player", email);
                    user.totalQuizzes = p.has("total_quizzes") ? p.get("total_quizzes").getAsInt() : 0;
                    user.bestScore = p.has("best_score") ? p.get("best_score").getAsInt() : 0;
                    user.avgAccuracy = p.has("avg_accuracy") ? p.get("avg_accuracy").getAsFloat() : 0;
                    user.streak = p.has("streak") ? p.get("streak").getAsInt() : 0;
                } else {
                    user = new UserProfile(uid, "Player", email);
                }
                saveSession(token, user);
                prefs.edit()
                    .putInt("total_quizzes", user.totalQuizzes)
                    .putInt("best_score", user.bestScore)
                    .putFloat("avg_accuracy", user.avgAccuracy)
                    .putInt("streak", user.streak)
                    .apply();
                UserProfile finalUser = user;
                mainHandler.post(() -> cb.onSuccess(finalUser));
            }
        } catch (Exception e) {
            // fallback
            UserProfile user = new UserProfile(uid, "Player", email);
            saveSession(token, user);
            mainHandler.post(() -> cb.onSuccess(user));
        }
    }

    // ── Save quiz result ──────────────────────────────────────────────────────
    public void saveQuizResult(int correct, int total, float accuracy, VoidCallback cb) {
        new Thread(() -> {
            try {
                UserProfile local = getLocalUser();
                if (local == null) { mainHandler.post(() -> cb.onError("Not logged in")); return; }

                int newTotal = local.totalQuizzes + 1;
                int newBest = Math.max(local.bestScore, (int) accuracy);
                float newAvg = ((local.avgAccuracy * local.totalQuizzes) + accuracy) / newTotal;

                // Update local prefs immediately
                prefs.edit()
                    .putInt("total_quizzes", newTotal)
                    .putInt("best_score", newBest)
                    .putFloat("avg_accuracy", newAvg)
                    .apply();

                // Patch Supabase
                JsonObject body = new JsonObject();
                body.addProperty("total_quizzes", newTotal);
                body.addProperty("best_score", newBest);
                body.addProperty("avg_accuracy", newAvg);

                Request req = new Request.Builder()
                    .url(SUPABASE_URL + "/rest/v1/profiles?id=eq." + local.id)
                    .patch(RequestBody.create(body.toString(), MediaType.get("application/json")))
                    .addHeader("apikey", SUPABASE_ANON_KEY)
                    .addHeader("Authorization", "Bearer " + getToken())
                    .addHeader("Content-Type", "application/json")
                    .addHeader("Prefer", "return=minimal")
                    .build();

                try (Response res = http.newCall(req).execute()) {
                    mainHandler.post(() -> cb.onSuccess());
                }
            } catch (Exception e) {
                mainHandler.post(() -> cb.onError(e.getMessage()));
            }
        }).start();
    }

    // ── Leaderboard ───────────────────────────────────────────────────────────
    public void getLeaderboard(LeaderboardCallback cb) {
        new Thread(() -> {
            try {
                Request req = new Request.Builder()
                    .url(SUPABASE_URL + "/rest/v1/profiles?select=username,best_score,total_quizzes,avg_accuracy&order=best_score.desc&limit=50")
                    .get()
                    .addHeader("apikey", SUPABASE_ANON_KEY)
                    .addHeader("Authorization", "Bearer " + getToken())
                    .build();

                try (Response res = http.newCall(req).execute()) {
                    String json = res.body().string();
                    JsonArray arr = gson.fromJson(json, JsonArray.class);
                    List<LeaderboardEntry> list = new ArrayList<>();
                    if (arr != null) {
                        for (int i = 0; i < arr.size(); i++) {
                            JsonObject o = arr.get(i).getAsJsonObject();
                            LeaderboardEntry e = new LeaderboardEntry();
                            e.username = o.has("username") ? o.get("username").getAsString() : "Player";
                            e.bestScore = o.has("best_score") ? o.get("best_score").getAsInt() : 0;
                            e.totalQuizzes = o.has("total_quizzes") ? o.get("total_quizzes").getAsInt() : 0;
                            e.avgAccuracy = o.has("avg_accuracy") ? o.get("avg_accuracy").getAsFloat() : 0;
                            list.add(e);
                        }
                    }
                    mainHandler.post(() -> cb.onSuccess(list));
                }
            } catch (Exception e) {
                mainHandler.post(() -> cb.onError(e.getMessage()));
            }
        }).start();
    }
}