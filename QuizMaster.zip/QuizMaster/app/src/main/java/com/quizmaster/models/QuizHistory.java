package com.quizmaster.models;

public class QuizHistory {
    public String id, category, difficulty, date;
    public int totalQuestions, correct;
    public float accuracy;
    public boolean isAiGenerated;

    public QuizHistory() {}
    public QuizHistory(String category, String difficulty, int total, int correct, boolean ai) {
        this.category = category;
        this.difficulty = difficulty;
        this.totalQuestions = total;
        this.correct = correct;
        this.accuracy = total > 0 ? (correct * 100f / total) : 0;
        this.isAiGenerated = ai;
        this.date = new java.text.SimpleDateFormat("MMM dd, yyyy", java.util.Locale.getDefault())
            .format(new java.util.Date());
    }
}