package com.quizmaster.models;

public class BookmarkedQuestion {
    public String question, correctAnswer, category, difficulty;
    public long timestamp;

    public BookmarkedQuestion() {}
    public BookmarkedQuestion(String question, String correctAnswer, String category, String difficulty) {
        this.question = question; this.correctAnswer = correctAnswer;
        this.category = category; this.difficulty = difficulty;
        this.timestamp = System.currentTimeMillis();
    }
}