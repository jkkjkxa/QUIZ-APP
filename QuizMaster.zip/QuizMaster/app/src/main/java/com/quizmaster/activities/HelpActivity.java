package com.quizmaster.activities;

import android.os.Bundle;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import com.quizmaster.R;
import com.quizmaster.utils.ThemeManager;

public class HelpActivity extends AppCompatActivity {
    @Override
    @SuppressWarnings({"deprecation", "unchecked"})
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ThemeManager.getInstance().init(this);
        setContentView(R.layout.activity_help);
        ThemeManager.getInstance().applyToActivity(this);
        ((ImageView) findViewById(R.id.ivBack)).setOnClickListener(v -> finish());
    }
}