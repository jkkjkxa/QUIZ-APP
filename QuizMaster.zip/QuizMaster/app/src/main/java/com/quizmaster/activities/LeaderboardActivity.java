package com.quizmaster.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.quizmaster.R;
import com.quizmaster.utils.ThemeManager;
import com.quizmaster.adapters.LeaderboardAdapter;
import com.quizmaster.utils.SupabaseManager;

public class LeaderboardActivity extends AppCompatActivity {
    @Override
    @SuppressWarnings({"deprecation", "unchecked"})
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ThemeManager.getInstance().init(this);
        setContentView(R.layout.activity_leaderboard);
        ThemeManager.getInstance().applyToActivity(this);

        ImageView ivBack = findViewById(R.id.ivBack);
        ivBack.setOnClickListener(v -> finish());

        ProgressBar progress = findViewById(R.id.progressLeader);
        RecyclerView rv      = findViewById(R.id.rvLeaderboard);
        rv.setLayoutManager(new LinearLayoutManager(this));

        SupabaseManager.getInstance().getLeaderboard(new SupabaseManager.LeaderboardCallback() {
            @Override
            public void onSuccess(java.util.List<com.quizmaster.models.LeaderboardEntry> entries) {
                progress.setVisibility(View.GONE);
                rv.setVisibility(View.VISIBLE);
                rv.setAdapter(new LeaderboardAdapter(entries));
            }
            @Override
            public void onError(String msg) {
                progress.setVisibility(View.GONE);
                Toast.makeText(LeaderboardActivity.this, "Failed to load: " + msg, Toast.LENGTH_SHORT).show();
            }
        });
    }
}