package com.quizmaster.activities;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import com.quizmaster.R;
import com.quizmaster.models.Question;
import com.quizmaster.utils.GroqManager;
import com.quizmaster.utils.LocalDataManager;
import com.quizmaster.utils.ThemeManager;
import java.io.Serializable;
import java.util.List;

public class AiQuizActivity extends AppCompatActivity {

    private static final int PICK_PDF = 101;
    private boolean isPdfMode = false;
    private int questionCount = 5;
    private String difficulty = "easy";
    private Uri pdfUri = null;
    private String pdfName = null;

    private android.widget.TextView btnTabTopic, btnTabPdf;
    private android.widget.TextView btnAi5, btnAi10, btnAi15;
    private android.widget.TextView btnAiEasy, btnAiMedium, btnAiHard, btnGenerate;
    private LinearLayout panelTopic, panelPdf;
    private EditText etTopic;
    private TextView tvPdfName, tvStatus;
    private ProgressBar progressAi;
    private CardView cardPickPdf;

    @SuppressWarnings({"deprecation","unchecked"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ThemeManager.getInstance().init(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ai_quiz);
        ThemeManager.getInstance().applyToActivity(this);
        LocalDataManager.getInstance().init(this);

        bindViews();
        setTabTopic();

        btnTabTopic.setOnClickListener(v -> setTabTopic());
        btnTabPdf.setOnClickListener(v   -> setTabPdf());

        btnAi5.setOnClickListener(v  -> setCount(5));
        btnAi10.setOnClickListener(v -> setCount(10));
        btnAi15.setOnClickListener(v -> setCount(15));

        btnAiEasy.setOnClickListener(v   -> setDifficulty("easy"));
        btnAiMedium.setOnClickListener(v -> setDifficulty("medium"));
        btnAiHard.setOnClickListener(v   -> setDifficulty("hard"));

        cardPickPdf.setOnClickListener(v -> pickPdf());
        btnGenerate.setOnClickListener(v -> generate());

        ((android.widget.ImageView) findViewById(R.id.ivBack))
            .setOnClickListener(v -> finish());
    }

    private void bindViews() {
        btnTabTopic  = findViewById(R.id.btnTabTopic);
        btnTabPdf    = findViewById(R.id.btnTabPdf);
        btnAi5       = findViewById(R.id.btnAi5);
        btnAi10      = findViewById(R.id.btnAi10);
        btnAi15      = findViewById(R.id.btnAi15);
        btnAiEasy    = findViewById(R.id.btnAiEasy);
        btnAiMedium  = findViewById(R.id.btnAiMedium);
        btnAiHard    = findViewById(R.id.btnAiHard);
        btnGenerate  = findViewById(R.id.btnGenerate);
        panelTopic   = findViewById(R.id.panelTopic);
        panelPdf     = findViewById(R.id.panelPdf);
        etTopic      = findViewById(R.id.etTopic);
        tvPdfName    = findViewById(R.id.tvPdfName);
        tvStatus     = findViewById(R.id.tvStatus);
        progressAi   = findViewById(R.id.progressAi);
        cardPickPdf  = findViewById(R.id.cardPickPdf);
    }

    private void setTabTopic() {
        isPdfMode = false;
        panelTopic.setVisibility(View.VISIBLE);
        panelPdf.setVisibility(View.GONE);
        btnTabTopic.setBackgroundResource(R.drawable.bg_button_primary);
        btnTabTopic.setTextColor(0xFFFFFFFF);
        btnTabPdf.setBackgroundColor(0);
        btnTabPdf.setTextColor(0xFFB0B0CC);
    }

    private void setTabPdf() {
        isPdfMode = true;
        panelTopic.setVisibility(View.GONE);
        panelPdf.setVisibility(View.VISIBLE);
        btnTabPdf.setBackgroundResource(R.drawable.bg_button_primary);
        btnTabPdf.setTextColor(0xFFFFFFFF);
        btnTabTopic.setBackgroundColor(0);
        btnTabTopic.setTextColor(0xFFB0B0CC);
    }

    private void setCount(int n) {
        questionCount = n;
        for (android.widget.TextView b : new android.widget.TextView[]{btnAi5, btnAi10, btnAi15}) {
            b.setBackgroundResource(R.drawable.bg_option_normal);
            b.setTextColor(0xFFB0B0CC);
        }
        android.widget.TextView active = n == 5 ? btnAi5 : n == 10 ? btnAi10 : btnAi15;
        active.setBackgroundResource(R.drawable.bg_option_selected);
        active.setTextColor(0xFFFFFFFF);
    }

    private void setDifficulty(String d) {
        difficulty = d;
        btnAiEasy.setBackgroundResource(R.drawable.bg_option_normal);   btnAiEasy.setTextColor(0xFFB0B0CC);
        btnAiMedium.setBackgroundResource(R.drawable.bg_option_normal); btnAiMedium.setTextColor(0xFFB0B0CC);
        btnAiHard.setBackgroundResource(R.drawable.bg_option_normal);   btnAiHard.setTextColor(0xFFB0B0CC);
        if ("easy".equals(d))   { btnAiEasy.setBackgroundResource(R.drawable.bg_difficulty_easy);   btnAiEasy.setTextColor(0xFF00E5A0); }
        if ("medium".equals(d)) { btnAiMedium.setBackgroundResource(R.drawable.bg_difficulty_medium); btnAiMedium.setTextColor(0xFFFFB347); }
        if ("hard".equals(d))   { btnAiHard.setBackgroundResource(R.drawable.bg_difficulty_hard);   btnAiHard.setTextColor(0xFFFF4757); }
    }

    private void pickPdf() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("application/pdf");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(Intent.createChooser(i, "Select PDF"), PICK_PDF);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_PDF && resultCode == Activity.RESULT_OK && data != null) {
            pdfUri = data.getData();
            pdfName = getFileName(pdfUri);
            tvPdfName.setText("Selected: " + pdfName);
        }
    }

    private String getFileName(Uri uri) {
        String result = "Selected PDF";
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) result = c.getString(idx);
            }
        } catch (Exception ignored) {}
        return result;
    }

    private void generate() {
        if (isPdfMode && pdfUri == null) {
            showStatus("Please select a PDF file first.");
            return;
        }
        if (!isPdfMode) {
            String topic = etTopic.getText().toString().trim();
            if (topic.isEmpty()) {
                showStatus("Please enter a topic.");
                return;
            }
        }

        setLoading(true, isPdfMode ? "Reading PDF and generating questions..." : "Generating questions with AI...");

        GroqManager.QuestionsCallback cb = new GroqManager.QuestionsCallback() {
            @Override
            public void onSuccess(List<Question> questions) {
                setLoading(false, "");
                if (isPdfMode) LocalDataManager.getInstance().unlockBadge("pdf_quiz");
                LocalDataManager.getInstance().unlockBadge("ai_quiz");

                String topicName = isPdfMode
                    ? (pdfName != null ? pdfName : "PDF Quiz")
                    : etTopic.getText().toString().trim();

                Intent i = new Intent(AiQuizActivity.this, QuizActivity.class);
                i.putExtra("questions", (Serializable) questions);
                i.putExtra("cat_name", topicName);
                i.putExtra("cat_emoji", "AI");
                i.putExtra("difficulty", difficulty);
                i.putExtra("count", questions.size());
                i.putExtra("ai_generated", true);
                startActivity(i);
            }

            @Override
            public void onError(String msg) {
                setLoading(false, "");
                showStatus("Error: " + (msg != null ? msg : "Unknown error. Check internet connection."));
            }
        };

        if (isPdfMode) {
            showStatus("Reading PDF content...");
            new Thread(() -> {
                String text = LocalDataManager.extractTextFromPdf(this, pdfUri);
                if (text == null || text.trim().length() < 100) {
                    runOnUiThread(() -> {
                        setLoading(false, "");
                        showStatus("Could not extract enough text from PDF. Try a text-based PDF.");
                    });
                    return;
                }
                runOnUiThread(() -> showStatus("Generating " + questionCount + " questions from PDF..."));
                GroqManager.getInstance().generateFromPdfText(text, questionCount, difficulty, cb);
            }).start();
        } else {
            String topic = etTopic.getText().toString().trim();
            GroqManager.getInstance().generateFromTopic(topic, questionCount, difficulty, cb);
        }
    }

    private void setLoading(boolean loading, String msg) {
        btnGenerate.setEnabled(!loading);
        btnGenerate.setAlpha(loading ? 0.5f : 1.0f);
        progressAi.setVisibility(loading ? View.VISIBLE : View.GONE);
        if (!msg.isEmpty()) showStatus(msg);
        else tvStatus.setVisibility(View.GONE);
    }

    private void showStatus(String msg) {
        tvStatus.setText(msg);
        tvStatus.setVisibility(View.VISIBLE);
    }
}