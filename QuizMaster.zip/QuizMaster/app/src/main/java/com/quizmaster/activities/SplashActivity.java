package com.quizmaster.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import androidx.appcompat.app.AppCompatActivity;
import com.quizmaster.R;
import com.quizmaster.utils.LocalDataManager;
import com.quizmaster.utils.SupabaseManager;
import com.quizmaster.utils.ThemeManager;

public class SplashActivity extends AppCompatActivity {
    @Override
    @SuppressWarnings({"deprecation", "unchecked"})
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // Init all managers
        SupabaseManager.getInstance().init(this);
        LocalDataManager.getInstance().init(this);
        ThemeManager.getInstance().init(this);

        // Apply saved theme bg
        ThemeManager.getInstance().applyToActivity(this);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            Intent next = SupabaseManager.getInstance().isLoggedIn()
                ? new Intent(this, HomeActivity.class)
                : new Intent(this, LoginActivity.class);
            startActivity(next);
            finish();
        }, 2200);
    }
}
