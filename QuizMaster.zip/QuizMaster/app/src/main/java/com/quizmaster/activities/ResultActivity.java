package com.quizmaster.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.quizmaster.R;
import com.quizmaster.utils.ThemeManager;
import com.quizmaster.models.QuizResult;

public class ResultActivity extends AppCompatActivity {
    @Override
    @SuppressWarnings({"deprecation", "unchecked"})
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ThemeManager.getInstance().init(this);
        setContentView(R.layout.activity_result);
        ThemeManager.getInstance().applyToActivity(this);

        QuizResult result = (QuizResult) getIntent().getSerializableExtra("result");
        String catEmoji  = getIntent().getStringExtra("cat_emoji");
        String catId     = getIntent().getStringExtra("cat_id");
        String difficulty= getIntent().getStringExtra("difficulty");

        if (result == null) { finish(); return; }

        ((TextView) findViewById(R.id.tvCategory)).setText(result.category + " · " + result.difficulty.toUpperCase());
        ((TextView) findViewById(R.id.tvScorePercent)).setText((int) result.accuracy + "%");
        ((TextView) findViewById(R.id.tvCorrect)).setText(String.valueOf(result.correct));
        ((TextView) findViewById(R.id.tvWrong)).setText(String.valueOf(result.wrong));
        ((TextView) findViewById(R.id.tvMessage)).setText(getMessage((int) result.accuracy));

        android.widget.TextView btnAgain = (android.widget.TextView) findViewById(R.id.btnPlayAgain);
        android.widget.TextView btnHome = (android.widget.TextView) findViewById(R.id.btnHome);

        btnAgain.setOnClickListener(v -> {
            Intent i = new Intent(this, QuizActivity.class);
            i.putExtra("count", result.totalQuestions);
            i.putExtra("difficulty", difficulty);
            i.putExtra("cat_name", result.category);
            i.putExtra("cat_emoji", catEmoji);
            i.putExtra("cat_id", catId);
            startActivity(i);
            finish();
        });

        btnHome.setOnClickListener(v -> {
            startActivity(new Intent(this, HomeActivity.class));
            finishAffinity();
        });
    }

    private String getMessage(int acc) {
        if (acc >= 90) return "🏆 Outstanding! You're a genius!";
        if (acc >= 70) return "🌟 Great job! You know your stuff!";
        if (acc >= 50) return "👍 Not bad! Keep practicing!";
        if (acc >= 30) return "📚 Keep studying, you'll get better!";
        return "💪 Don't give up! Try again!";
    }
}