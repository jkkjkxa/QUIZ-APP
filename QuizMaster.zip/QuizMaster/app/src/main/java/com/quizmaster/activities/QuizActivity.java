package com.quizmaster.activities;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.Html;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import com.quizmaster.R;
import com.quizmaster.models.BookmarkedQuestion;
import com.quizmaster.models.Question;
import com.quizmaster.models.QuizHistory;
import com.quizmaster.models.QuizResponse;
import com.quizmaster.models.QuizResult;
import com.quizmaster.network.RetrofitClient;
import com.quizmaster.utils.GroqManager;
import com.quizmaster.utils.LocalDataManager;
import com.quizmaster.utils.SupabaseManager;
import com.quizmaster.utils.ThemeManager;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import java.io.Serializable;
import java.util.*;

public class QuizActivity extends AppCompatActivity {

    private TextView tvQNum, tvTimer, tvScore, tvQuestion, tvCategory;
    private TextView tvFeedback, tvCorrectAnswer, tvExplanation, tvHint, tvBookmark;
    private ProgressBar progressBar, progressExplain;
    private android.widget.TextView btnA, btnB, btnC, btnD, btnNext;
    private CardView cardFeedback;

    private List<Question> questions = new ArrayList<>();
    private int index = 0, score = 0, correct = 0;
    private String selectedAnswer = null, correctAnswer = null;
    private boolean answered = false, isAiGenerated = false;

    private CountDownTimer timer;
    private static final int TIMER_SECS = 30;

    private String catName, catEmoji, catId, difficulty;
    private int totalQuestions;
    private boolean hintUsed = false;

    @SuppressWarnings({"deprecation","unchecked"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ThemeManager.getInstance().init(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);
        ThemeManager.getInstance().applyToActivity(this);
        LocalDataManager.getInstance().init(this);

        catName        = getIntent().getStringExtra("cat_name");
        catEmoji       = getIntent().getStringExtra("cat_emoji");
        catId          = getIntent().getStringExtra("cat_id");
        difficulty     = getIntent().getStringExtra("difficulty");
        totalQuestions = getIntent().getIntExtra("count", 5);
        isAiGenerated  = getIntent().getBooleanExtra("ai_generated", false);

        // Pre-loaded AI questions?
        try {
            List<Question> preloaded = (List<Question>) getIntent().getSerializableExtra("questions");
            if (preloaded != null && !preloaded.isEmpty()) questions = preloaded;
        } catch (Exception ignored) {}

        bindViews();
        if (catEmoji != null && !catEmoji.isEmpty()) {
            tvCategory.setText(catEmoji + " " + catName);
        } else {
            tvCategory.setText(catName != null ? catName : "Quiz");
        }
        progressBar.setMax(100);

        if (questions.isEmpty()) loadQuestions();
        else showQuestion();
    }

    private void bindViews() {
        tvQNum          = findViewById(R.id.tvQuestionNum);
        tvTimer         = findViewById(R.id.tvTimer);
        tvScore         = findViewById(R.id.tvScore);
        tvQuestion      = findViewById(R.id.tvQuestion);
        tvCategory      = findViewById(R.id.tvCategory);
        tvFeedback      = findViewById(R.id.tvFeedback);
        tvCorrectAnswer = findViewById(R.id.tvCorrectAnswer);
        tvExplanation   = findViewById(R.id.tvExplanation);
        tvHint          = findViewById(R.id.tvHint);
        tvBookmark      = findViewById(R.id.tvBookmark);
        progressBar     = findViewById(R.id.progressBar);
        progressExplain = findViewById(R.id.progressExplain);
        cardFeedback    = findViewById(R.id.cardFeedback);
        btnA = findViewById(R.id.btnA);
        btnB = findViewById(R.id.btnB);
        btnC = findViewById(R.id.btnC);
        btnD = findViewById(R.id.btnD);
        btnNext = findViewById(R.id.btnNext);

        for (android.widget.TextView b : getOptionButtons()) {
            b.setOnClickListener(v -> onOptionSelected((android.widget.TextView) v));
        }
        btnNext.setOnClickListener(v -> nextQuestion());
        if (tvHint != null)     tvHint.setOnClickListener(v -> requestHint());
        if (tvBookmark != null) tvBookmark.setOnClickListener(v -> toggleBookmark());
    }

    private android.widget.TextView[] getOptionButtons() {
        return new android.widget.TextView[]{btnA, btnB, btnC, btnD};
    }

    private void loadQuestions() {
        tvQuestion.setText("Loading questions...");
        for (android.widget.TextView b : getOptionButtons()) b.setVisibility(View.INVISIBLE);

        String catParam = (catId != null && !catId.isEmpty() && !catId.equals("all")) ? catId : null;

        RetrofitClient.getApi().getQuestions(totalQuestions, catParam, difficulty, "multiple")
            .enqueue(new Callback<QuizResponse>() {
                @Override
                public void onResponse(Call<QuizResponse> call, Response<QuizResponse> res) {
                    for (android.widget.TextView b : getOptionButtons()) b.setVisibility(View.VISIBLE);
                    if (res.isSuccessful() && res.body() != null
                            && res.body().results != null
                            && !res.body().results.isEmpty()) {
                        questions = res.body().results;
                        try {
                            com.google.gson.Gson g = new com.google.gson.Gson();
                            LocalDataManager.getInstance().cacheQuestions(catName, g.toJson(questions));
                        } catch (Exception ignored) {}
                        showQuestion();
                    } else {
                        int code = res.body() != null ? res.body().response_code : -1;
                        if (code == 5) {
                            // Rate limit from OpenTDB - wait and retry once
                            tvQuestion.setText("Too many requests. Retrying in 5 seconds...");
                            new android.os.Handler().postDelayed(() ->
                                RetrofitClient.getApi()
                                    .getQuestions(totalQuestions, catParam, difficulty, "multiple")
                                    .enqueue(this), 5000);
                        } else {
                            tryOfflineCache();
                        }
                    }
                }
                @Override
                public void onFailure(Call<QuizResponse> call, Throwable t) {
                    for (android.widget.TextView b : getOptionButtons()) b.setVisibility(View.VISIBLE);
                    tryOfflineCache();
                }
            });
    }

    private void tryOfflineCache() {
        String cached = LocalDataManager.getInstance().getCachedQuestions(catName);
        if (cached != null) {
            try {
                com.google.gson.Gson g = new com.google.gson.Gson();
                com.google.gson.reflect.TypeToken<List<Question>> tt =
                    new com.google.gson.reflect.TypeToken<List<Question>>(){};
                List<Question> cached_q = g.fromJson(cached, tt.getType());
                if (cached_q != null && !cached_q.isEmpty()) {
                    questions = cached_q;
                    tvQuestion.setText("");
                    showQuestion();
                    Toast.makeText(this, "Offline mode - using cached questions", Toast.LENGTH_SHORT).show();
                    return;
                }
            } catch (Exception ignored) {}
        }
        tvQuestion.setText("Failed to load questions. Check your internet connection and try again.");
        for (android.widget.TextView b : getOptionButtons()) b.setVisibility(View.GONE);
    }

    private void showQuestion() {
        if (index >= questions.size()) { finishQuiz(); return; }
        answered = false; selectedAnswer = null; hintUsed = false;

        Question q = questions.get(index);
        correctAnswer = Html.fromHtml(q.correct_answer, Html.FROM_HTML_MODE_COMPACT).toString();

        int prog = (int)((index / (float) questions.size()) * 100);
        progressBar.setProgress(prog);
        tvQNum.setText("Question " + (index + 1) + "/" + questions.size());
        tvScore.setText("Score: " + score);
        tvQuestion.setText(Html.fromHtml(q.question, Html.FROM_HTML_MODE_COMPACT));

        // Bookmark icon
        if (tvBookmark != null) {
            String qText = Html.fromHtml(q.question, Html.FROM_HTML_MODE_COMPACT).toString();
            tvBookmark.setText(LocalDataManager.getInstance().isBookmarked(qText) ? "Saved" : "Save");
        }

        // Build shuffled options
        List<String> options = new ArrayList<>();
        if (q.incorrect_answers != null) {
            for (String s : q.incorrect_answers)
                options.add(Html.fromHtml(s, Html.FROM_HTML_MODE_COMPACT).toString());
        }
        options.add(correctAnswer);
        if (LocalDataManager.getInstance().isShuffleEnabled()) Collections.shuffle(options);

        android.widget.TextView[] btns = getOptionButtons();
        String[] labels = {"A", "B", "C", "D"};
        for (int i = 0; i < btns.length; i++) {
            if (i < options.size()) {
                btns[i].setVisibility(View.VISIBLE);
                btns[i].setText(labels[i] + ".  " + options.get(i));
                btns[i].setTag(options.get(i));
                btns[i].setBackgroundResource(R.drawable.bg_option_normal);
                btns[i].setTextColor(Color.WHITE);
                btns[i].setEnabled(true);
            } else {
                btns[i].setVisibility(View.GONE);
            }
        }

        // Reset feedback
        if (cardFeedback != null) cardFeedback.setVisibility(View.GONE);
        if (tvCorrectAnswer != null) tvCorrectAnswer.setVisibility(View.GONE);
        if (tvExplanation != null)   tvExplanation.setVisibility(View.GONE);
        if (progressExplain != null) progressExplain.setVisibility(View.GONE);
        if (btnNext != null)         btnNext.setVisibility(View.GONE);
        if (tvHint != null)          { tvHint.setEnabled(true); tvHint.setAlpha(1.0f); }

        if (LocalDataManager.getInstance().isTimerEnabled()) startTimer();
    }

    private void onOptionSelected(android.widget.TextView tapped) {
        if (answered) return;
        answered = true;
        selectedAnswer = tapped.getTag() != null ? tapped.getTag().toString() : "";
        cancelTimer();
        evaluateAnswer(tapped);
    }

    private void evaluateAnswer(android.widget.TextView tapped) {
        boolean isCorrect = selectedAnswer != null && selectedAnswer.equals(correctAnswer);

        for (android.widget.TextView b : getOptionButtons()) {
            b.setEnabled(false);
            String tag = b.getTag() != null ? b.getTag().toString() : "";
            if (tag.equals(correctAnswer)) {
                b.setBackgroundResource(R.drawable.bg_option_correct);
                b.setTextColor(Color.parseColor("#00E5A0"));
            } else if (b == tapped && !isCorrect) {
                b.setBackgroundResource(R.drawable.bg_option_wrong);
                b.setTextColor(Color.parseColor("#FF4757"));
            }
        }

        if (cardFeedback != null) cardFeedback.setVisibility(View.VISIBLE);

        if (isCorrect) {
            correct++;
            score += difficultyPoints();
            if (tvFeedback != null) {
                tvFeedback.setText("Correct!");
                tvFeedback.setTextColor(Color.parseColor("#00E5A0"));
            }
            if (cardFeedback != null)
                cardFeedback.setCardBackgroundColor(Color.parseColor("#1A3D30"));
            LocalDataManager.getInstance().vibrateCorrect();
        } else {
            if (tvFeedback != null) {
                tvFeedback.setText("Wrong!");
                tvFeedback.setTextColor(Color.parseColor("#FF4757"));
            }
            if (cardFeedback != null)
                cardFeedback.setCardBackgroundColor(Color.parseColor("#3D1A1A"));
            if (tvCorrectAnswer != null) {
                tvCorrectAnswer.setVisibility(View.VISIBLE);
                tvCorrectAnswer.setText("Correct answer: " + correctAnswer);
            }
            LocalDataManager.getInstance().vibrateWrong();
            // AI explanation if enabled
            if (LocalDataManager.getInstance().isAiExplainEnabled()) {
                fetchExplanation();
            }
        }

        tvScore.setText("Score: " + score);
        if (btnNext != null) btnNext.setVisibility(View.VISIBLE);
    }

    private void fetchExplanation() {
        if (questions.isEmpty() || index >= questions.size()) return;
        if (progressExplain != null) progressExplain.setVisibility(View.VISIBLE);
        String questionText = Html.fromHtml(
            questions.get(index).question, Html.FROM_HTML_MODE_COMPACT).toString();

        GroqManager.getInstance().explainAnswer(
            questionText, correctAnswer,
            selectedAnswer != null ? selectedAnswer : "nothing",
            new GroqManager.TextCallback() {
                @Override public void onSuccess(String text) {
                    if (progressExplain != null) progressExplain.setVisibility(View.GONE);
                    if (tvExplanation != null) {
                        tvExplanation.setText("AI: " + text);
                        tvExplanation.setVisibility(View.VISIBLE);
                    }
                }
                @Override public void onError(String msg) {
                    if (progressExplain != null) progressExplain.setVisibility(View.GONE);
                }
            });
    }

    private void requestHint() {
        if (answered || hintUsed) return;
        hintUsed = true;
        if (tvHint != null) { tvHint.setEnabled(false); tvHint.setAlpha(0.4f); }
        String questionText = Html.fromHtml(
            questions.get(index).question, Html.FROM_HTML_MODE_COMPACT).toString();

        GroqManager.getInstance().getHint(questionText, correctAnswer,
            new GroqManager.TextCallback() {
                @Override public void onSuccess(String text) {
                    Toast.makeText(QuizActivity.this, "Hint: " + text, Toast.LENGTH_LONG).show();
                }
                @Override public void onError(String msg) {
                    if (tvHint != null) { tvHint.setEnabled(true); tvHint.setAlpha(1.0f); }
                    hintUsed = false;
                    Toast.makeText(QuizActivity.this, "Hint unavailable right now.", Toast.LENGTH_SHORT).show();
                }
            });
    }

    private void toggleBookmark() {
        if (questions.isEmpty() || index >= questions.size()) return;
        String qText = Html.fromHtml(questions.get(index).question, Html.FROM_HTML_MODE_COMPACT).toString();
        String cat   = questions.get(index).category != null ? questions.get(index).category : catName;
        String diff  = questions.get(index).difficulty != null ? questions.get(index).difficulty : difficulty;

        if (LocalDataManager.getInstance().isBookmarked(qText)) {
            LocalDataManager.getInstance().removeBookmark(qText);
            if (tvBookmark != null) tvBookmark.setText("Save");
            Toast.makeText(this, "Bookmark removed", Toast.LENGTH_SHORT).show();
        } else {
            LocalDataManager.getInstance().bookmarkQuestion(
                new BookmarkedQuestion(qText, correctAnswer, cat, diff));
            if (tvBookmark != null) tvBookmark.setText("Saved");
            Toast.makeText(this, "Bookmarked!", Toast.LENGTH_SHORT).show();
        }
    }

    private int difficultyPoints() {
        if ("hard".equals(difficulty))   return 30;
        if ("medium".equals(difficulty)) return 20;
        return 10;
    }

    private void nextQuestion() { index++; showQuestion(); }

    private void startTimer() {
        cancelTimer();
        if (tvTimer != null) tvTimer.setTextColor(Color.parseColor("#6C63FF"));
        timer = new CountDownTimer(TIMER_SECS * 1000L, 1000) {
            @Override public void onTick(long ms) {
                int secs = (int)(ms / 1000);
                if (tvTimer != null) {
                    tvTimer.setText(String.valueOf(secs));
                    if (secs <= 5)       tvTimer.setTextColor(Color.parseColor("#FF4757"));
                    else if (secs <= 10) tvTimer.setTextColor(Color.parseColor("#FFB347"));
                    else                 tvTimer.setTextColor(Color.parseColor("#6C63FF"));
                }
            }
            @Override public void onFinish() {
                if (tvTimer != null) tvTimer.setText("0");
                if (!answered) { answered = true; evaluateAnswer(null); }
            }
        }.start();
    }

    private void cancelTimer() {
        if (timer != null) { timer.cancel(); timer = null; }
    }

    private void finishQuiz() {
        float accuracy = questions.size() > 0 ? (correct * 100f / questions.size()) : 0;

        // Save history locally
        QuizHistory history = new QuizHistory(catName, difficulty, questions.size(), correct, isAiGenerated);
        LocalDataManager.getInstance().saveQuizHistory(history);

        if (isAiGenerated) LocalDataManager.getInstance().unlockBadge("ai_quiz");
        if (accuracy >= 90) LocalDataManager.getInstance().unlockBadge("accuracy_90");
        if (accuracy >= 100) LocalDataManager.getInstance().unlockBadge("perfect");

        // Save to Supabase
        SupabaseManager.getInstance().saveQuizResult(correct, questions.size(), accuracy,
            new SupabaseManager.VoidCallback() {
                @Override public void onSuccess() {}
                @Override public void onError(String msg) {}
            });

        QuizResult result = new QuizResult(catName, difficulty, questions.size(), correct);
        Intent i = new Intent(this, ResultActivity.class);
        i.putExtra("result", result);
        i.putExtra("cat_emoji", catEmoji);
        i.putExtra("cat_id", catId);
        i.putExtra("difficulty", difficulty);
        startActivity(i);
        finish();
    }

    @Override protected void onDestroy() { super.onDestroy(); cancelTimer(); }
}