package com.quizmaster.adapters;

import android.graphics.Color;
import android.view.*;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.quizmaster.R;
import com.quizmaster.models.Badge;
import java.util.List;

public class BadgeAdapter extends RecyclerView.Adapter<BadgeAdapter.VH> {
    private final List<Badge> list;
    public BadgeAdapter(List<Badge> list) { this.list = list; }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup p, int t) {
        View v = LayoutInflater.from(p.getContext()).inflate(R.layout.item_badge, p, false);
        return new VH(v);
    }

    @Override public void onBindViewHolder(@NonNull VH h, int pos) {
        Badge b = list.get(pos);
        h.tvEmoji.setText(b.emoji);
        h.tvName.setText(b.name);
        h.tvDesc.setText(b.description);
        if (b.unlocked) {
            h.card.setCardBackgroundColor(Color.parseColor("#1A1A2E"));
            h.tvEmoji.setAlpha(1f);
            h.tvName.setTextColor(Color.parseColor("#FFFFFF"));
            h.tvStatus.setText("✓ Unlocked");
            h.tvStatus.setTextColor(Color.parseColor("#00E5A0"));
        } else {
            h.card.setCardBackgroundColor(Color.parseColor("#0F0E17"));
            h.tvEmoji.setAlpha(0.3f);
            h.tvName.setTextColor(Color.parseColor("#6B6B8A"));
            h.tvStatus.setText("🔒 Locked");
            h.tvStatus.setTextColor(Color.parseColor("#6B6B8A"));
        }
    }

    @Override public int getItemCount() { return list.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvEmoji, tvName, tvDesc, tvStatus;
        CardView card;
        VH(View v) {
            super(v);
            tvEmoji  = v.findViewById(R.id.tvBadgeEmoji);
            tvName   = v.findViewById(R.id.tvBadgeName);
            tvDesc   = v.findViewById(R.id.tvBadgeDesc);
            tvStatus = v.findViewById(R.id.tvBadgeStatus);
            card     = v.findViewById(R.id.cardBadge);
        }
    }
}