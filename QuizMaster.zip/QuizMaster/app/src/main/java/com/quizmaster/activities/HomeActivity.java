package com.quizmaster.activities;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import com.quizmaster.R;
import com.quizmaster.models.UserProfile;
import com.quizmaster.utils.LocalDataManager;
import com.quizmaster.utils.SupabaseManager;
import com.quizmaster.utils.ThemeManager;
import android.view.View;
import android.view.ViewGroup;

public class HomeActivity extends AppCompatActivity {

    @SuppressWarnings({"deprecation","unchecked"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ThemeManager.getInstance().init(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        SupabaseManager.getInstance().init(this);
        LocalDataManager.getInstance().init(this);

        UserProfile user = SupabaseManager.getInstance().getLocalUser();
        if (user == null) {
            startActivity(new Intent(this, LoginActivity.class));
            finish(); return;
        }

        LocalDataManager.getInstance().updateDailyStreak();
        applyTheme();
        refreshUI();
        wireNav();
    }

    private void applyTheme() {
        ThemeManager.Theme t = ThemeManager.getInstance().getTheme();
        // Window bg
        getWindow().getDecorView().setBackgroundColor(t.bg);
        // Root scroll view bg
        View root = findViewById(R.id.scrollRoot);
        if (root != null) root.setBackgroundColor(t.bg);
        // Apply to all CardViews
        applyToViewGroup((ViewGroup) getWindow().getDecorView(), t);
        // Banner card color
        try {
            CardView bannerCard = (CardView) ((ViewGroup)
                ((ViewGroup) getWindow().getDecorView())
                .getChildAt(0)).getChildAt(0);
        } catch (Exception ignored) {}
    }

    private void applyToViewGroup(ViewGroup vg, ThemeManager.Theme t) {
        for (int i = 0; i < vg.getChildCount(); i++) {
            View child = vg.getChildAt(i);
            if (child instanceof CardView) {
                // Don't change banner card (it has primary color bg)
                String tag = child.getTag() != null ? child.getTag().toString() : "";
                if (!"banner".equals(tag)) {
                    ((CardView) child).setCardBackgroundColor(t.surface);
                }
            }
            if (child instanceof ViewGroup) {
                applyToViewGroup((ViewGroup) child, t);
            }
        }
    }

    private void wireNav() {
        findViewById(R.id.btnStartQuiz).setOnClickListener(v ->
            startActivity(new Intent(this, CategoryActivity.class)));
        ((CardView) findViewById(R.id.cardAiQuiz)).setOnClickListener(v ->
            startActivity(new Intent(this, AiQuizActivity.class)));
        ((CardView) findViewById(R.id.cardLeaderboard)).setOnClickListener(v ->
            startActivity(new Intent(this, LeaderboardActivity.class)));
        ((CardView) findViewById(R.id.cardStats)).setOnClickListener(v ->
            startActivity(new Intent(this, StatsActivity.class)));
        ((CardView) findViewById(R.id.cardHistory)).setOnClickListener(v ->
            startActivity(new Intent(this, HistoryActivity.class)));
        ((CardView) findViewById(R.id.cardBadges)).setOnClickListener(v ->
            startActivity(new Intent(this, BadgesActivity.class)));
        ((CardView) findViewById(R.id.cardBookmarks)).setOnClickListener(v ->
            startActivity(new Intent(this, BookmarksActivity.class)));
        ((CardView) findViewById(R.id.cardSettings)).setOnClickListener(v ->
            startActivity(new Intent(this, SettingsActivity.class)));
        ((CardView) findViewById(R.id.cardProfile)).setOnClickListener(v ->
            startActivity(new Intent(this, ProfileActivity.class)));
        ((CardView) findViewById(R.id.cardHelp)).setOnClickListener(v ->
            startActivity(new Intent(this, HelpActivity.class)));
        ((CardView) findViewById(R.id.cardAbout)).setOnClickListener(v ->
            startActivity(new Intent(this, AboutActivity.class)));
        findViewById(R.id.ivProfile).setOnClickListener(v ->
            startActivity(new Intent(this, ProfileActivity.class)));
    }

    private void refreshUI() {
        UserProfile user = SupabaseManager.getInstance().getLocalUser();
        if (user == null) return;
        ThemeManager.Theme t = ThemeManager.getInstance().getTheme();
        ((TextView) findViewById(R.id.tvUsername)).setText(user.username);
        ((TextView) findViewById(R.id.tvAvatarInitial)).setText(
            user.username != null && !user.username.isEmpty()
                ? String.valueOf(user.username.charAt(0)).toUpperCase() : "P");
        ((TextView) findViewById(R.id.tvTotalQuizzes)).setText(
            String.valueOf(LocalDataManager.getInstance().getHistory().size()));
        ((TextView) findViewById(R.id.tvTotalQuizzes)).setTextColor(t.primary);
        ((TextView) findViewById(R.id.tvBestScore)).setText(user.bestScore + "%");
        ((TextView) findViewById(R.id.tvBestScore)).setTextColor(t.correct);
        ((TextView) findViewById(R.id.tvStreak)).setText(
            String.valueOf(LocalDataManager.getInstance().getStreak()));
        ((TextView) findViewById(R.id.tvStreak)).setTextColor(t.accent);
        // Banner button text color matches theme
        View btn = findViewById(R.id.btnStartQuiz);
        if (btn instanceof TextView) ((TextView)btn).setTextColor(t.primary);
    }

    @Override
    protected void onResume() {
        super.onResume();
        applyTheme();
        refreshUI();
    }
}