package com.quizmaster.network;

import com.quizmaster.models.QuizResponse;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface TriviaApi {
    @GET("api.php")
    Call<QuizResponse> getQuestions(
        @Query("amount")     int amount,
        @Query("category")   String category,
        @Query("difficulty") String difficulty,
        @Query("type")       String type
    );
}