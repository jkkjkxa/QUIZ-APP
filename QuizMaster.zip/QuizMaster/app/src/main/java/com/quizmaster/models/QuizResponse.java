package com.quizmaster.models;

import java.util.List;

public class QuizResponse {
    public int response_code;
    public List<Question> results;
}