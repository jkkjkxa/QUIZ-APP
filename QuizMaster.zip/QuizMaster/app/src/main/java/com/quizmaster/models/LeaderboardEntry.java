package com.quizmaster.models;

public class LeaderboardEntry {
    public String username;
    public int bestScore, totalQuizzes;
    public float avgAccuracy;
}