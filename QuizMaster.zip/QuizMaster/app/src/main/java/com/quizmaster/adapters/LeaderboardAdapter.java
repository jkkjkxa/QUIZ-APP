package com.quizmaster.adapters;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.quizmaster.R;
import com.quizmaster.models.LeaderboardEntry;
import java.util.List;

public class LeaderboardAdapter extends RecyclerView.Adapter<LeaderboardAdapter.VH> {
    private final List<LeaderboardEntry> list;

    public LeaderboardAdapter(List<LeaderboardEntry> list) { this.list = list; }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_leaderboard, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        LeaderboardEntry e = list.get(pos);
        int rank = pos + 1;
        if (rank == 1)      { h.rank.setText("🥇"); h.rank.setBackgroundResource(R.drawable.bg_leaderboard_gold); }
        else if (rank == 2) { h.rank.setText("🥈"); h.rank.setBackgroundResource(R.drawable.bg_leaderboard_silver); }
        else if (rank == 3) { h.rank.setText("🥉"); h.rank.setBackgroundResource(R.drawable.bg_leaderboard_bronze); }
        else                { h.rank.setText(String.valueOf(rank)); h.rank.setBackgroundResource(R.drawable.bg_timer_circle); }
        h.name.setText(e.username);
        h.quizzes.setText(e.totalQuizzes + " quizzes played");
        h.score.setText(e.bestScore + "%");
    }

    @Override public int getItemCount() { return list.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView rank, name, quizzes, score;
        VH(View v) {
            super(v);
            rank    = v.findViewById(R.id.tvRank);
            name    = v.findViewById(R.id.tvName);
            quizzes = v.findViewById(R.id.tvQuizzesPlayed);
            score   = v.findViewById(R.id.tvScore);
        }
    }
}