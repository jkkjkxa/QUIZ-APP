package com.quizmaster.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.quizmaster.R;
import com.quizmaster.models.UserProfile;
import com.quizmaster.utils.SupabaseManager;

public class RegisterActivity extends AppCompatActivity {
    private EditText etUsername, etEmail, etPassword, etConfirm;
    private android.widget.TextView btnRegister;
    private TextView tvError, tvLogin;

    @Override
    @SuppressWarnings({"deprecation", "unchecked"})
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        SupabaseManager.getInstance().init(this);

        etUsername = findViewById(R.id.etUsername);
        etEmail    = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        etConfirm  = findViewById(R.id.etConfirmPassword);
        btnRegister= findViewById(R.id.btnRegister);
        tvError    = findViewById(R.id.tvError);
        tvLogin    = findViewById(R.id.tvLogin);

        btnRegister.setOnClickListener(v -> attemptRegister());
        tvLogin.setOnClickListener(v -> finish());
    }

    private void attemptRegister() {
        String user = etUsername.getText().toString().trim();
        String email= etEmail.getText().toString().trim();
        String pass = etPassword.getText().toString();
        String conf = etConfirm.getText().toString();

        if (user.isEmpty() || email.isEmpty() || pass.isEmpty() || conf.isEmpty()) {
            showError("Please fill all fields."); return;
        }
        if (!pass.equals(conf)) { showError("Passwords do not match."); return; }
        if (pass.length() < 6)  { showError("Password must be at least 6 characters."); return; }

        btnRegister.setEnabled(false);
        btnRegister.setText("Creating account...");
        tvError.setVisibility(View.GONE);

        SupabaseManager.getInstance().register(email, pass, user, new SupabaseManager.AuthCallback() {
            @Override public void onSuccess(UserProfile u) {
                startActivity(new Intent(RegisterActivity.this, HomeActivity.class));
                finishAffinity();
            }
            @Override public void onError(String msg) {
                showError(msg);
                btnRegister.setEnabled(true);
                btnRegister.setText("CREATE ACCOUNT");
            }
        });
    }

    private void showError(String msg) {
        tvError.setText(msg);
        tvError.setVisibility(View.VISIBLE);
    }
}