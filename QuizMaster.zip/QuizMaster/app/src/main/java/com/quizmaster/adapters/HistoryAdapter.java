package com.quizmaster.adapters;

import android.graphics.Color;
import android.view.*;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.quizmaster.R;
import com.quizmaster.models.QuizHistory;
import java.util.List;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.VH> {
    private final List<QuizHistory> list;
    public HistoryAdapter(List<QuizHistory> list) { this.list = list; }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup p, int t) {
        View v = LayoutInflater.from(p.getContext()).inflate(R.layout.item_history, p, false);
        return new VH(v);
    }

    @Override public void onBindViewHolder(@NonNull VH h, int pos) {
        QuizHistory q = list.get(pos);
        h.tvCategory.setText((q.isAiGenerated ? "🤖 " : "") + q.category);
        h.tvDate.setText(q.date);
        h.tvScore.setText((int)q.accuracy + "%");
        h.tvDetail.setText(q.correct + "/" + q.totalQuestions + " correct · " + q.difficulty);
        int color = q.accuracy >= 70 ? Color.parseColor("#00E5A0") :
                    q.accuracy >= 40 ? Color.parseColor("#FFB347") : Color.parseColor("#FF4757");
        h.tvScore.setTextColor(color);
    }

    @Override public int getItemCount() { return list.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvCategory, tvDate, tvScore, tvDetail;
        VH(View v) {
            super(v);
            tvCategory = v.findViewById(R.id.tvHistoryCategory);
            tvDate     = v.findViewById(R.id.tvHistoryDate);
            tvScore    = v.findViewById(R.id.tvHistoryScore);
            tvDetail   = v.findViewById(R.id.tvHistoryDetail);
        }
    }
}