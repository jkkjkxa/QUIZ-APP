package com.quizmaster.models;

import java.io.Serializable;

public class QuizResult implements Serializable {
    public String category, difficulty;
    public int totalQuestions, correct, wrong;
    public float accuracy;

    public QuizResult(String category, String difficulty, int total, int correct) {
        this.category = category;
        this.difficulty = difficulty;
        this.totalQuestions = total;
        this.correct = correct;
        this.wrong = total - correct;
        this.accuracy = total > 0 ? (correct * 100f / total) : 0;
    }
}