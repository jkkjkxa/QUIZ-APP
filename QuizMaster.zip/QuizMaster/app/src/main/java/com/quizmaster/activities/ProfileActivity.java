package com.quizmaster.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.quizmaster.R;
import com.quizmaster.models.UserProfile;
import com.quizmaster.utils.LocalDataManager;
import com.quizmaster.utils.SupabaseManager;

public class ProfileActivity extends AppCompatActivity {
    @Override
    @SuppressWarnings({"deprecation", "unchecked"})
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        LocalDataManager.getInstance().init(this);

        ((ImageView) findViewById(R.id.ivBack)).setOnClickListener(v -> finish());

        UserProfile user = SupabaseManager.getInstance().getLocalUser();
        if (user == null) { finish(); return; }

        String initials = (user.username != null && !user.username.isEmpty())
            ? String.valueOf(user.username.charAt(0)).toUpperCase() : "?";

        ((TextView) findViewById(R.id.tvAvatarLetter)).setText(initials);
        ((TextView) findViewById(R.id.tvProfileName)).setText(user.username);
        ((TextView) findViewById(R.id.tvProfileEmail)).setText(user.email);
        ((TextView) findViewById(R.id.tvStatQuizzes)).setText(
            String.valueOf(LocalDataManager.getInstance().getHistory().size()));
        ((TextView) findViewById(R.id.tvStatAccuracy)).setText((int) user.avgAccuracy + "%");
        ((TextView) findViewById(R.id.tvStatBest)).setText(user.bestScore + "%");
        ((TextView) findViewById(R.id.tvStatStreak)).setText(
            "🔥 " + LocalDataManager.getInstance().getStreak());

        findViewById(R.id.btnSettings).setOnClickListener(v ->
            startActivity(new Intent(this, SettingsActivity.class)));

        findViewById(R.id.btnLogout).setOnClickListener(v -> {
            SupabaseManager.getInstance().logout();
            Intent i = new Intent(this, LoginActivity.class);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
        });
    }
}