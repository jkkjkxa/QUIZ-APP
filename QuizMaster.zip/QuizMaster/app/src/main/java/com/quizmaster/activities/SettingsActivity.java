package com.quizmaster.activities;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import com.quizmaster.R;
import com.quizmaster.utils.LocalDataManager;
import com.quizmaster.utils.SupabaseManager;
import com.quizmaster.utils.ThemeManager;

public class SettingsActivity extends AppCompatActivity {

    private View themeCard1, themeCard2, themeCard3;
    private TextView tvCheck1, tvCheck2, tvCheck3, tvCurrentTheme;
    private ThemeManager.Theme currentTheme;

    @SuppressWarnings({"deprecation","unchecked"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ThemeManager.getInstance().init(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        applyThemeBg();

        LocalDataManager.getInstance().init(this);
        currentTheme = ThemeManager.getInstance().getTheme();

        // Back
        findViewById(R.id.ivBack).setOnClickListener(v -> finish());

        // Theme views
        themeCard1    = findViewById(R.id.themeDeepPurple);
        themeCard2    = findViewById(R.id.themeOcean);
        themeCard3    = findViewById(R.id.themeAmoled);
        tvCheck1      = findViewById(R.id.tvTheme1Check);
        tvCheck2      = findViewById(R.id.tvTheme2Check);
        tvCheck3      = findViewById(R.id.tvTheme3Check);
        tvCurrentTheme= findViewById(R.id.tvCurrentTheme);

        updateThemeUI();

        themeCard1.setOnClickListener(v -> applyTheme(ThemeManager.THEME_DARK));
        themeCard2.setOnClickListener(v -> applyTheme(ThemeManager.THEME_OCEAN));
        themeCard3.setOnClickListener(v -> applyTheme(ThemeManager.THEME_AMOLED));

        // Sound
        Switch sw = findViewById(R.id.switchSound);
        sw.setChecked(LocalDataManager.getInstance().isSoundEnabled());
        sw.setOnCheckedChangeListener((b, c) -> LocalDataManager.getInstance().toggleSound());

        // Vibrate
        Switch sv = findViewById(R.id.switchVibrate);
        sv.setChecked(LocalDataManager.getInstance().isVibrationEnabled());
        sv.setOnCheckedChangeListener((b, c) -> LocalDataManager.getInstance().toggleVibration());

        // Timer
        Switch st = findViewById(R.id.switchTimer);
        st.setChecked(LocalDataManager.getInstance().isTimerEnabled());
        st.setOnCheckedChangeListener((b, c) -> LocalDataManager.getInstance().setTimerEnabled(c));

        // AI Explain
        Switch sa = findViewById(R.id.switchAiExplain);
        sa.setChecked(LocalDataManager.getInstance().isAiExplainEnabled());
        sa.setOnCheckedChangeListener((b, c) -> LocalDataManager.getInstance().setAiExplainEnabled(c));

        // Shuffle
        Switch ss = findViewById(R.id.switchShuffle);
        ss.setChecked(LocalDataManager.getInstance().isShuffleEnabled());
        ss.setOnCheckedChangeListener((b, c) -> LocalDataManager.getInstance().setShuffleEnabled(c));

        // Clear history
        findViewById(R.id.rowClearHistory).setOnClickListener(v ->
            new AlertDialog.Builder(this)
                .setTitle("Clear History")
                .setMessage("Delete all quiz history? This cannot be undone.")
                .setPositiveButton("Clear", (d, w) -> {
                    LocalDataManager.getInstance().clearHistory();
                    Toast.makeText(this, "History cleared", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null).show());

        // Logout
        findViewById(R.id.rowLogout).setOnClickListener(v ->
            new AlertDialog.Builder(this)
                .setTitle("Logout")
                .setMessage("Are you sure?")
                .setPositiveButton("Logout", (d, w) -> {
                    SupabaseManager.getInstance().logout();
                    Intent i = new Intent(this, LoginActivity.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);
                })
                .setNegativeButton("Cancel", null).show());
    }

    private void applyTheme(String name) {
        ThemeManager.getInstance().setTheme(name);
        currentTheme = ThemeManager.getInstance().getTheme();
        applyThemeBg();
        updateThemeUI();
        // Apply to switches too
        updateSwitchColors();
        Toast.makeText(this, currentTheme.name + " theme applied!", Toast.LENGTH_SHORT).show();
    }

    private void applyThemeBg() {
        ThemeManager.Theme t = ThemeManager.getInstance().getTheme();
        getWindow().getDecorView().setBackgroundColor(t.bg);
        // Also tint the section labels
        try {
            // Find all CardViews and set surface color
            View root = getWindow().getDecorView();
            tintViews(root, t);
        } catch (Exception ignored) {}
    }

    private void tintViews(View v, ThemeManager.Theme t) {
        if (v instanceof CardView) {
            ((CardView)v).setCardBackgroundColor(t.surface);
        }
        if (v instanceof android.view.ViewGroup) {
            android.view.ViewGroup vg = (android.view.ViewGroup) v;
            for (int i = 0; i < vg.getChildCount(); i++) tintViews(vg.getChildAt(i), t);
        }
    }

    private void updateThemeUI() {
        String name = ThemeManager.getInstance().getThemeName();
        // Reset all to unselected
        themeCard1.setBackgroundResource(R.drawable.bg_theme_option);
        themeCard2.setBackgroundResource(R.drawable.bg_theme_option);
        themeCard3.setBackgroundResource(R.drawable.bg_theme_option);
        tvCheck1.setVisibility(View.GONE);
        tvCheck2.setVisibility(View.GONE);
        tvCheck3.setVisibility(View.GONE);

        // Highlight selected
        switch (name) {
            case ThemeManager.THEME_DARK:
                themeCard1.setBackgroundResource(R.drawable.bg_theme_option_selected);
                tvCheck1.setVisibility(View.VISIBLE);
                break;
            case ThemeManager.THEME_OCEAN:
                themeCard2.setBackgroundResource(R.drawable.bg_theme_option_selected);
                tvCheck2.setVisibility(View.VISIBLE);
                break;
            case ThemeManager.THEME_AMOLED:
                themeCard3.setBackgroundResource(R.drawable.bg_theme_option_selected);
                tvCheck3.setVisibility(View.VISIBLE);
                break;
        }
        tvCurrentTheme.setText("Current: " + name);
        tvCurrentTheme.setTextColor(currentTheme.primary);
    }

    private void updateSwitchColors() {
        int color = currentTheme.primary;
        int[] switchIds = {R.id.switchSound, R.id.switchVibrate,
                          R.id.switchTimer, R.id.switchAiExplain, R.id.switchShuffle};
        for (int id : switchIds) {
            Switch sw = findViewById(id);
            if (sw != null) {
                sw.setThumbTintList(android.content.res.ColorStateList.valueOf(color));
            }
        }
    }
}