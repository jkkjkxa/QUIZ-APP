package com.quizmaster.models;

public class Category {
    public String name, emoji, description, apiId;
    public int color;

    public Category(String name, String emoji, String description, String apiId, int color) {
        this.name = name;
        this.emoji = emoji;
        this.description = description;
        this.apiId = apiId;
        this.color = color;
    }
}