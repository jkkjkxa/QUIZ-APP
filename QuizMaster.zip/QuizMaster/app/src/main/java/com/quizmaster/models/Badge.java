package com.quizmaster.models;

public class Badge {
    public String id, name, description, emoji;
    public boolean unlocked;
    public int requiredValue;

    public Badge(String id, String name, String description, String emoji, int requiredValue) {
        this.id = id; this.name = name; this.description = description;
        this.emoji = emoji; this.requiredValue = requiredValue;
    }
}