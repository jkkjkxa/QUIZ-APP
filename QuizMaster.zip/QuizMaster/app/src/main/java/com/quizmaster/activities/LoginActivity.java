package com.quizmaster.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.quizmaster.R;
import com.quizmaster.models.UserProfile;
import com.quizmaster.utils.SupabaseManager;
import com.quizmaster.utils.ThemeManager;

public class LoginActivity extends AppCompatActivity {
    private EditText etEmail, etPassword;
    private android.widget.TextView btnLogin;
    private TextView tvError, tvRegister;

    @Override
    @SuppressWarnings({"deprecation", "unchecked"})
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ThemeManager.getInstance().init(this);
        setContentView(R.layout.activity_login);
        ThemeManager.getInstance().applyToActivity(this);
        SupabaseManager.getInstance().init(this);

        etEmail    = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin   = findViewById(R.id.btnLogin);
        tvError    = findViewById(R.id.tvError);
        tvRegister = findViewById(R.id.tvRegister);

        btnLogin.setOnClickListener(v -> attemptLogin());
        tvRegister.setOnClickListener(v ->
            startActivity(new Intent(this, RegisterActivity.class)));
        findViewById(R.id.tvForgot).setOnClickListener(v ->
            Toast.makeText(this, "Check your email inbox for reset link.", Toast.LENGTH_SHORT).show());
    }

    private void attemptLogin() {
        String email = etEmail.getText().toString().trim();
        String pass  = etPassword.getText().toString();
        if (email.isEmpty() || pass.isEmpty()) { showError("Please fill all fields."); return; }
        btnLogin.setEnabled(false);
        btnLogin.setText("Logging in...");
        tvError.setVisibility(View.GONE);

        SupabaseManager.getInstance().login(email, pass, new SupabaseManager.AuthCallback() {
            @Override public void onSuccess(UserProfile user) {
                startActivity(new Intent(LoginActivity.this, HomeActivity.class));
                finish();
            }
            @Override public void onError(String message) {
                showError(message);
                btnLogin.setEnabled(true);
                btnLogin.setText("LOGIN");
            }
        });
    }

    private void showError(String msg) {
        tvError.setText(msg);
        tvError.setVisibility(View.VISIBLE);
    }
}