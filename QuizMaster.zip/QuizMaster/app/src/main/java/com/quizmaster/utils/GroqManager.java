package com.quizmaster.utils;

import android.os.Handler;
import android.os.Looper;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.quizmaster.models.Question;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import okhttp3.*;

/**
 * GroqManager - uses Groq API (ultra-fast LLM inference) for quiz generation,
 * hints, and explanations. Falls back gracefully on error.
 */
public class GroqManager {

    private static final String API_KEY = "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";
    private static final String BASE_URL = "https://api.groq.com/openai/v1/chat/completions";
    // Use llama3-70b for best quality, fallback to llama3-8b if rate limited
    private static final String MODEL_PRIMARY  = "llama3-70b-8192";
    private static final String MODEL_FALLBACK = "llama-3.1-8b-instant";

    private static GroqManager instance;
    private final OkHttpClient http;
    private final Gson gson = new Gson();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    public interface QuestionsCallback {
        void onSuccess(List<Question> questions);
        void onError(String msg);
    }

    public interface TextCallback {
        void onSuccess(String text);
        void onError(String msg);
    }

    private GroqManager() {
        http = new OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build();
    }

    public static GroqManager getInstance() {
        if (instance == null) instance = new GroqManager();
        return instance;
    }

    // ── Generate questions from a topic ──────────────────────────────────────
    public void generateFromTopic(String topic, int count, String difficulty, QuestionsCallback cb) {
        String prompt = "Generate exactly " + count + " multiple choice quiz questions about: " + topic + ".\n" +
            "Difficulty: " + difficulty + ".\n" +
            "Rules:\n" +
            "- Each question must have exactly 4 options\n" +
            "- Questions must be factual and educational\n" +
            "- Make questions specific and interesting, not generic\n" +
            "- Return ONLY a valid JSON array, no markdown, no explanation\n\n" +
            "Format:\n" +
            "[{\"question\":\"...\",\"correct_answer\":\"...\",\"incorrect_answers\":[\"...\",\"...\",\"...\"],\"difficulty\":\"" + difficulty + "\",\"category\":\"" + topic + "\"}]";
        callGroq(prompt, MODEL_PRIMARY, count, cb);
    }

    // ── Generate questions from PDF text ─────────────────────────────────────
    public void generateFromPdfText(String pdfText, int count, String difficulty, QuestionsCallback cb) {
        int maxLen = 6000;
        String trimmed = pdfText.length() > maxLen ? pdfText.substring(0, maxLen) : pdfText;
        String prompt = "Based on the following document content, generate exactly " + count +
            " multiple choice quiz questions. Difficulty: " + difficulty + ".\n" +
            "Rules:\n" +
            "- Each question must be directly based on the document content\n" +
            "- Each question must have exactly 4 options (1 correct + 3 wrong)\n" +
            "- Return ONLY a valid JSON array, no markdown, no explanation\n\n" +
            "Document:\n" + trimmed + "\n\n" +
            "Format:\n" +
            "[{\"question\":\"...\",\"correct_answer\":\"...\",\"incorrect_answers\":[\"...\",\"...\",\"...\"],\"difficulty\":\"" + difficulty + "\",\"category\":\"Document Quiz\"}]";
        callGroq(prompt, MODEL_PRIMARY, count, cb);
    }

    // ── Explain a wrong answer ────────────────────────────────────────────────
    public void explainAnswer(String question, String correctAnswer, String wrongAnswer, TextCallback cb) {
        String prompt = "Quiz question: " + question + "\n" +
            "Correct answer: " + correctAnswer + "\n" +
            "Student answered: " + wrongAnswer + "\n\n" +
            "In 2 sentences, explain why '" + correctAnswer + "' is correct and why '" + wrongAnswer + "' is wrong. Be clear and educational. No markdown.";
        callGroqText(prompt, MODEL_FALLBACK, cb);
    }

    // ── Get a hint for a question ─────────────────────────────────────────────
    public void getHint(String question, String correctAnswer, TextCallback cb) {
        String prompt = "Quiz question: " + question + "\n" +
            "Give ONE short hint (max 15 words) that guides toward the answer '" + correctAnswer + "' without revealing it. No markdown.";
        callGroqText(prompt, MODEL_FALLBACK, cb);
    }

    // ── Core: call Groq and parse questions ───────────────────────────────────
    private void callGroq(String prompt, String model, int expectedCount, QuestionsCallback cb) {
        new Thread(() -> {
            try {
                String raw = callGroqRaw(prompt, model, 2048);
                if (raw == null || raw.trim().isEmpty()) {
                    // Try fallback model
                    if (!model.equals(MODEL_FALLBACK)) {
                        mainHandler.post(() -> mainHandler.postDelayed(() ->
                            callGroq(prompt, MODEL_FALLBACK, expectedCount, cb), 1000));
                    } else {
                        mainHandler.post(() -> cb.onError("AI returned empty response. Please try again."));
                    }
                    return;
                }

                // Extract JSON array from response
                String json = extractJsonArray(raw);
                if (json == null) {
                    mainHandler.post(() -> cb.onError("AI response format error. Please try again."));
                    return;
                }

                JsonArray arr = gson.fromJson(json, JsonArray.class);
                List<Question> questions = new ArrayList<>();
                for (int i = 0; i < arr.size(); i++) {
                    try {
                        JsonObject o = arr.get(i).getAsJsonObject();
                        Question q = new Question();
                        q.question       = o.get("question").getAsString();
                        q.correct_answer = o.get("correct_answer").getAsString();
                        q.difficulty     = o.has("difficulty") ? o.get("difficulty").getAsString() : "medium";
                        q.category       = o.has("category")  ? o.get("category").getAsString()  : "AI Quiz";
                        q.incorrect_answers = new ArrayList<>();
                        JsonArray inc = o.getAsJsonArray("incorrect_answers");
                        for (int j = 0; j < inc.size(); j++) {
                            q.incorrect_answers.add(inc.get(j).getAsString());
                        }
                        if (q.incorrect_answers.size() >= 3) {
                            questions.add(q);
                        }
                    } catch (Exception ignored) {}
                }

                if (questions.isEmpty()) {
                    mainHandler.post(() -> cb.onError("Could not parse questions. Try a different topic."));
                    return;
                }

                List<Question> finalQ = questions;
                mainHandler.post(() -> cb.onSuccess(finalQ));

            } catch (Exception e) {
                String msg = e.getMessage() != null ? e.getMessage() : "Network error";
                if (msg.contains("rate_limit") || msg.contains("429")) {
                    mainHandler.post(() -> cb.onError("Rate limit reached. Please wait 30 seconds and try again."));
                } else if (msg.contains("timeout") || msg.contains("connect")) {
                    mainHandler.post(() -> cb.onError("Connection timeout. Check your internet and try again."));
                } else {
                    mainHandler.post(() -> cb.onError("AI error: " + msg));
                }
            }
        }).start();
    }

    // ── Core: call Groq and return plain text ─────────────────────────────────
    private void callGroqText(String prompt, String model, TextCallback cb) {
        new Thread(() -> {
            try {
                String result = callGroqRaw(prompt, model, 300);
                if (result == null || result.trim().isEmpty()) {
                    mainHandler.post(() -> cb.onError("No response from AI."));
                } else {
                    String clean = result.trim().replaceAll("^[\\s*#-]+", "");
                    mainHandler.post(() -> cb.onSuccess(clean));
                }
            } catch (Exception e) {
                mainHandler.post(() -> cb.onError(e.getMessage()));
            }
        }).start();
    }

    // ── Raw HTTP call to Groq ─────────────────────────────────────────────────
    private String callGroqRaw(String prompt, String model, int maxTokens) throws Exception {
        JsonObject message = new JsonObject();
        message.addProperty("role", "user");
        message.addProperty("content", prompt);
        JsonArray messages = new JsonArray();
        messages.add(message);

        JsonObject body = new JsonObject();
        body.addProperty("model", model);
        body.add("messages", messages);
        body.addProperty("temperature", 0.7);
        body.addProperty("max_tokens", maxTokens);

        Request req = new Request.Builder()
            .url(BASE_URL)
            .post(RequestBody.create(body.toString(), MediaType.get("application/json; charset=utf-8")))
            .addHeader("Authorization", "Bearer " + API_KEY)
            .addHeader("Content-Type", "application/json")
            .build();

        try (Response res = http.newCall(req).execute()) {
            String responseBody = res.body().string();
            if (!res.isSuccessful()) {
                JsonObject err = gson.fromJson(responseBody, JsonObject.class);
                String errMsg = "HTTP " + res.code();
                if (err != null && err.has("error")) {
                    JsonObject e = err.getAsJsonObject("error");
                    errMsg = e.has("message") ? e.get("message").getAsString() : errMsg;
                }
                throw new Exception(errMsg);
            }
            JsonObject obj = gson.fromJson(responseBody, JsonObject.class);
            return obj.getAsJsonArray("choices")
                .get(0).getAsJsonObject()
                .getAsJsonObject("message")
                .get("content").getAsString();
        }
    }

    // ── Extract JSON array from possibly messy LLM response ──────────────────
    private String extractJsonArray(String raw) {
        if (raw == null) return null;
        // Remove markdown code blocks
        String clean = raw.replaceAll("```json", "").replaceAll("```", "").trim();
        // Find first [ and last ]
        int start = clean.indexOf('[');
        int end   = clean.lastIndexOf(']');
        if (start == -1 || end == -1 || end <= start) return null;
        return clean.substring(start, end + 1);
    }
}