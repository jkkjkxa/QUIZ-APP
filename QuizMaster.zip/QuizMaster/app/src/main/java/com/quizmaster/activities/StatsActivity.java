package com.quizmaster.activities;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.*;
import com.github.mikephil.charting.data.*;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.quizmaster.R;
import com.quizmaster.utils.ThemeManager;
import com.quizmaster.models.CategoryStat;
import com.quizmaster.models.QuizHistory;
import com.quizmaster.utils.LocalDataManager;
import java.util.*;

public class StatsActivity extends AppCompatActivity {
    @Override
    @SuppressWarnings({"deprecation", "unchecked"})
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ThemeManager.getInstance().init(this);
        setContentView(R.layout.activity_stats);
        ThemeManager.getInstance().applyToActivity(this);
        LocalDataManager.getInstance().init(this);

        ((ImageView) findViewById(R.id.ivBack)).setOnClickListener(v -> finish());

        List<QuizHistory> history = LocalDataManager.getInstance().getHistory();
        int total = history.size();
        float avg = 0;
        for (QuizHistory h : history) avg += h.accuracy;
        if (total > 0) avg /= total;

        ((TextView) findViewById(R.id.tvStatTotal)).setText(String.valueOf(total));
        ((TextView) findViewById(R.id.tvStatAvg)).setText((int) avg + "%");

        setupChart(history);
        setupCategoryStats();
    }

    private void setupChart(List<QuizHistory> history) {
        LineChart chart = findViewById(R.id.lineChart);
        chart.setBackgroundColor(Color.parseColor("#1A1A2E"));
        chart.getDescription().setEnabled(false);
        chart.getLegend().setEnabled(false);
        chart.setDrawGridBackground(false);
        chart.setTouchEnabled(false);

        int count = Math.min(10, history.size());
        List<Entry> entries = new ArrayList<>();
        for (int i = count - 1; i >= 0; i--) {
            entries.add(new Entry(count - i, history.get(i).accuracy));
        }

        if (entries.isEmpty()) {
            chart.setNoDataText("Play some quizzes to see your trend!");
            chart.setNoDataTextColor(Color.parseColor("#B0B0CC"));
            chart.invalidate(); return;
        }

        LineDataSet ds = new LineDataSet(entries, "Accuracy");
        ds.setColor(Color.parseColor("#6C63FF"));
        ds.setCircleColor(Color.parseColor("#FF6584"));
        ds.setLineWidth(2.5f);
        ds.setCircleRadius(4f);
        ds.setDrawValues(false);
        ds.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        ds.setDrawFilled(true);
        ds.setFillColor(Color.parseColor("#6C63FF"));
        ds.setFillAlpha(30);

        XAxis xAxis = chart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setTextColor(Color.parseColor("#B0B0CC"));
        xAxis.setDrawGridLines(false);
        xAxis.setGranularity(1f);

        YAxis left = chart.getAxisLeft();
        left.setTextColor(Color.parseColor("#B0B0CC"));
        left.setAxisMinimum(0f);
        left.setAxisMaximum(105f);
        left.setDrawGridLines(true);
        left.setGridColor(Color.parseColor("#2A2A4A"));
        left.setValueFormatter(new ValueFormatter() {
            @Override public String getFormattedValue(float v) { return (int)v + "%"; }
        });
        chart.getAxisRight().setEnabled(false);
        chart.setData(new LineData(ds));
        chart.animateX(800);
        chart.invalidate();
    }

    private void setupCategoryStats() {
        LinearLayout ll = findViewById(R.id.llCategoryStats);
        Map<String, CategoryStat> stats = LocalDataManager.getInstance().getCategoryStats();
        if (stats.isEmpty()) {
            TextView tv = new TextView(this);
            tv.setText("Play quizzes in different categories to see breakdown.");
            tv.setTextColor(Color.parseColor("#6B6B8A"));
            tv.setTextSize(13f);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 8, 0, 8);
            tv.setLayoutParams(lp);
            ll.addView(tv); return;
        }

        List<CategoryStat> sorted = new ArrayList<>(stats.values());
        sorted.sort((a, b) -> Float.compare(b.accuracy, a.accuracy));

        for (CategoryStat s : sorted) {
            View row = LayoutInflater.from(this).inflate(R.layout.item_category_stat, ll, false);
            ((TextView)row.findViewById(R.id.tvCatStatName)).setText(s.category);
            int col = s.accuracy >= 70 ? Color.parseColor("#00E5A0") :
                      s.accuracy >= 40 ? Color.parseColor("#FFB347") : Color.parseColor("#FF4757");
            TextView acc = row.findViewById(R.id.tvCatStatAcc);
            acc.setText((int)s.accuracy + "%");
            acc.setTextColor(col);
            ((ProgressBar)row.findViewById(R.id.pbCatStat)).setProgress((int)s.accuracy);
            ll.addView(row);
        }
    }
}