package com.quizmaster.models;

public class UserProfile {
    public String id, username, email;
    public int totalQuizzes, bestScore, streak;
    public float avgAccuracy;

    public UserProfile() {}

    public UserProfile(String id, String username, String email) {
        this.id = id;
        this.username = username;
        this.email = email;
    }
}