package com.quizmaster.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Vibrator;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.quizmaster.models.Badge;
import com.quizmaster.models.BookmarkedQuestion;
import com.quizmaster.models.CategoryStat;
import com.quizmaster.models.QuizHistory;
import java.lang.reflect.Type;
import java.util.*;

public class LocalDataManager {
    private static final String PREFS = "quizmaster_local";
    private static LocalDataManager instance;
    private SharedPreferences prefs;
    private final Gson gson = new Gson();
    private Context ctx;

    public static LocalDataManager getInstance() {
        if (instance == null) instance = new LocalDataManager();
        return instance;
    }

    public void init(Context context) {
        ctx = context.getApplicationContext();
        prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    // ── Sound & Vibration ─────────────────────────────────────────────────────
    public boolean isSoundEnabled()   { return prefs.getBoolean("sound_on", true); }
    public boolean isVibrationEnabled(){ return prefs.getBoolean("vibrate_on", true); }
    public void toggleSound()     { prefs.edit().putBoolean("sound_on", !isSoundEnabled()).apply(); }
    public void toggleVibration() { prefs.edit().putBoolean("vibrate_on", !isVibrationEnabled()).apply(); }

    public void vibrateWrong() {
        if (!isVibrationEnabled()) return;
        try {
            Vibrator v = (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null) {
                android.os.VibrationEffect effect =
                    android.os.VibrationEffect.createOneShot(200, android.os.VibrationEffect.DEFAULT_AMPLITUDE);
                v.vibrate(effect);
            }
        } catch (Exception ignored) {}
    }

    public void vibrateCorrect() {
        if (!isVibrationEnabled()) return;
        try {
            Vibrator v = (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null) {
                android.os.VibrationEffect effect =
                    android.os.VibrationEffect.createWaveform(new long[]{0, 50, 50, 50}, -1);
                v.vibrate(effect);
            }
        } catch (Exception ignored) {}
    }

    // ── Theme ─────────────────────────────────────────────────────────────────
    public boolean isDarkTheme() { return prefs.getBoolean("dark_theme", true); }
    public void setDarkTheme(boolean dark) { prefs.edit().putBoolean("dark_theme", dark).apply(); }

    // ── Quiz History ──────────────────────────────────────────────────────────
    public void saveQuizHistory(QuizHistory h) {
        List<QuizHistory> list = getHistory();
        list.add(0, h);
        if (list.size() > 100) list = list.subList(0, 100);
        prefs.edit().putString("history", gson.toJson(list)).apply();
        updateCategoryStats(h);
        checkAndUnlockBadges();
    }

    public List<QuizHistory> getHistory() {
        String json = prefs.getString("history", "[]");
        Type t = new TypeToken<List<QuizHistory>>(){}.getType();
        List<QuizHistory> list = gson.fromJson(json, t);
        return list != null ? list : new ArrayList<>();
    }

    public void clearHistory() { prefs.edit().remove("history").apply(); }

    // ── Category Stats ────────────────────────────────────────────────────────
    private void updateCategoryStats(QuizHistory h) {
        Map<String, CategoryStat> stats = getCategoryStats();
        CategoryStat stat = stats.getOrDefault(h.category, new CategoryStat(h.category, "📊"));
        stat.totalQuestions += h.totalQuestions;
        stat.correctAnswers += h.correct;
        stat.accuracy = stat.totalQuestions > 0 ? (stat.correctAnswers * 100f / stat.totalQuestions) : 0;
        stats.put(h.category, stat);
        prefs.edit().putString("cat_stats", gson.toJson(stats)).apply();
    }

    public Map<String, CategoryStat> getCategoryStats() {
        String json = prefs.getString("cat_stats", "{}");
        Type t = new TypeToken<Map<String, CategoryStat>>(){}.getType();
        Map<String, CategoryStat> m = gson.fromJson(json, t);
        return m != null ? m : new HashMap<>();
    }

    // ── Bookmarks ─────────────────────────────────────────────────────────────
    public void bookmarkQuestion(BookmarkedQuestion q) {
        List<BookmarkedQuestion> list = getBookmarks();
        // Avoid duplicates
        for (BookmarkedQuestion b : list) {
            if (b.question.equals(q.question)) return;
        }
        list.add(0, q);
        prefs.edit().putString("bookmarks", gson.toJson(list)).apply();
    }

    public void removeBookmark(String question) {
        List<BookmarkedQuestion> list = getBookmarks();
        list.removeIf(b -> b.question.equals(question));
        prefs.edit().putString("bookmarks", gson.toJson(list)).apply();
    }

    public List<BookmarkedQuestion> getBookmarks() {
        String json = prefs.getString("bookmarks", "[]");
        Type t = new TypeToken<List<BookmarkedQuestion>>(){}.getType();
        List<BookmarkedQuestion> list = gson.fromJson(json, t);
        return list != null ? list : new ArrayList<>();
    }

    public boolean isBookmarked(String question) {
        for (BookmarkedQuestion b : getBookmarks()) {
            if (b.question.equals(question)) return true;
        }
        return false;
    }

    // ── Badges ────────────────────────────────────────────────────────────────
    public List<Badge> getAllBadges() {
        List<Badge> all = new ArrayList<>();
        all.add(new Badge("first_quiz",    "First Step",     "Complete your first quiz",        "🎯", 1));
        all.add(new Badge("quiz_5",        "Getting Started","Complete 5 quizzes",               "⭐", 5));
        all.add(new Badge("quiz_10",       "Quiz Addict",    "Complete 10 quizzes",              "🔟", 10));
        all.add(new Badge("quiz_50",       "Quiz Master",    "Complete 50 quizzes",              "🏆", 50));
        all.add(new Badge("perfect",       "Perfectionist",  "Get 100% on any quiz",             "💯", 100));
        all.add(new Badge("streak_3",      "On Fire",        "3-day login streak",               "🔥", 3));
        all.add(new Badge("streak_7",      "Weekly Warrior", "7-day login streak",               "⚡", 7));
        all.add(new Badge("streak_30",     "Unstoppable",    "30-day login streak",              "💫", 30));
        all.add(new Badge("ai_quiz",       "AI Explorer",    "Complete an AI-generated quiz",    "🤖", 1));
        all.add(new Badge("pdf_quiz",      "Book Worm",      "Generate a quiz from a PDF",       "📚", 1));
        all.add(new Badge("bookmark_5",    "Collector",      "Bookmark 5 questions",             "🔖", 5));
        all.add(new Badge("accuracy_90",   "Sharp Mind",     "Achieve 90%+ accuracy in a quiz",  "🧠", 90));
        all.add(new Badge("accuracy_100_3","Hat Trick",      "Get 100% three times",             "🎩", 3));
        all.add(new Badge("category_all",  "Explorer",       "Play every category",              "🗺️", 12));
        all.add(new Badge("night_owl",     "Night Owl",      "Play a quiz after midnight",       "🦉", 1));

        Set<String> unlocked = getUnlockedBadges();
        for (Badge b : all) b.unlocked = unlocked.contains(b.id);
        return all;
    }

    public Set<String> getUnlockedBadges() {
        String json = prefs.getString("badges", "[]");
        Type t = new TypeToken<Set<String>>(){}.getType();
        Set<String> s = gson.fromJson(json, t);
        return s != null ? s : new HashSet<>();
    }

    public void unlockBadge(String id) {
        Set<String> unlocked = getUnlockedBadges();
        unlocked.add(id);
        prefs.edit().putString("badges", gson.toJson(unlocked)).apply();
    }

    public boolean isBadgeUnlocked(String id) { return getUnlockedBadges().contains(id); }

    private void checkAndUnlockBadges() {
        List<QuizHistory> history = getHistory();
        int totalQuizzes = history.size();
        int perfectCount = 0;
        Set<String> categoriesPlayed = new HashSet<>();

        for (QuizHistory h : history) {
            if (h.accuracy >= 100) perfectCount++;
            if (h.category != null) categoriesPlayed.add(h.category);
        }

        if (totalQuizzes >= 1)   unlockBadge("first_quiz");
        if (totalQuizzes >= 5)   unlockBadge("quiz_5");
        if (totalQuizzes >= 10)  unlockBadge("quiz_10");
        if (totalQuizzes >= 50)  unlockBadge("quiz_50");
        if (perfectCount >= 1)   unlockBadge("perfect");
        if (perfectCount >= 3)   unlockBadge("accuracy_100_3");
        if (categoriesPlayed.size() >= 12) unlockBadge("category_all");
        if (getBookmarks().size() >= 5)    unlockBadge("bookmark_5");

        // Check night owl
        java.util.Calendar cal = java.util.Calendar.getInstance();
        int hour = cal.get(java.util.Calendar.HOUR_OF_DAY);
        if (hour >= 0 && hour < 4) unlockBadge("night_owl");

        // Streak badges
        int streak = getStreak();
        if (streak >= 3)  unlockBadge("streak_3");
        if (streak >= 7)  unlockBadge("streak_7");
        if (streak >= 30) unlockBadge("streak_30");
    }

    // ── Streak tracking ───────────────────────────────────────────────────────
    public int getStreak() { return prefs.getInt("streak", 0); }

    public void updateDailyStreak() {
        long lastDate = prefs.getLong("last_play_date", 0);
        long today = getDaysSinceEpoch();
        long daysSince = today - (lastDate > 0 ? lastDate : 0);

        if (daysSince == 0) return; // Already played today
        int streak = daysSince == 1 ? getStreak() + 1 : 1; // Reset if missed
        prefs.edit().putInt("streak", streak).putLong("last_play_date", today).apply();
        checkAndUnlockBadges();
    }

    private long getDaysSinceEpoch() {
        return System.currentTimeMillis() / (1000 * 60 * 60 * 24);
    }

    // ── Offline cache ─────────────────────────────────────────────────────────
    public void cacheQuestions(String category, String questionsJson) {
        prefs.edit().putString("cache_" + category, questionsJson)
             .putLong("cache_time_" + category, System.currentTimeMillis()).apply();
    }

    public String getCachedQuestions(String category) {
        long cacheTime = prefs.getLong("cache_time_" + category, 0);
        long age = System.currentTimeMillis() - cacheTime;
        if (age > 24 * 60 * 60 * 1000) return null; // 24h cache
        return prefs.getString("cache_" + category, null);
    }

    // ── PDF Text extract helper ───────────────────────────────────────────────
    public static String extractTextFromPdf(android.content.Context ctx, android.net.Uri uri) {
        StringBuilder sb = new StringBuilder();
        try {
            android.graphics.pdf.PdfRenderer renderer;
            android.os.ParcelFileDescriptor pfd =
                ctx.getContentResolver().openFileDescriptor(uri, "r");
            if (pfd == null) return "";
            // We can't do full text extraction with PdfRenderer (it's render-only)
            // Instead read bytes and extract readable text
            java.io.InputStream is = ctx.getContentResolver().openInputStream(uri);
            if (is == null) return "";
            byte[] bytes = new byte[is.available()];
            is.read(bytes);
            is.close();
            // Simple text extraction - find readable ASCII strings
            StringBuilder current = new StringBuilder();
            for (byte b : bytes) {
                char c = (char)(b & 0xFF);
                if (c >= 32 && c < 127) current.append(c);
                else if (current.length() > 4) {
                    sb.append(current).append(" ");
                    current = new StringBuilder();
                } else current = new StringBuilder();
            }
            pfd.close();
        } catch (Exception e) { return "PDF content: " + e.getMessage(); }
        return sb.toString();
    }

    // ── Settings prefs ────────────────────────────────────────────────────────
    public boolean isTimerEnabled()      { return prefs.getBoolean("timer_on", true); }
    public void setTimerEnabled(boolean v){ prefs.edit().putBoolean("timer_on", v).apply(); }

    public boolean isAiExplainEnabled()      { return prefs.getBoolean("ai_explain_on", true); }
    public void setAiExplainEnabled(boolean v){ prefs.edit().putBoolean("ai_explain_on", v).apply(); }

    public boolean isShuffleEnabled()      { return prefs.getBoolean("shuffle_on", true); }
    public void setShuffleEnabled(boolean v){ prefs.edit().putBoolean("shuffle_on", v).apply(); }

}