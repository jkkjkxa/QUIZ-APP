# QuizMaster 🧠

A full-featured, modern Android quiz app with Supabase authentication and leaderboard.

## ✨ Features

| Feature | Details |
|---------|---------|
| 🔐 Auth | Register / Login / Logout via Supabase |
| 📂 Categories | 12 categories (Science, History, Sports…) |
| ⚙️ Setup | Choose 3–20 questions & Easy/Medium/Hard difficulty |
| ⏱️ Timer | 30-second countdown per question with colour indicator |
| ✅ Feedback | Instant correct/wrong reveal + correct answer shown on wrong |
| 🏆 Leaderboard | Global ranking pulled from Supabase |
| 👤 Profile | Personal stats — quizzes played, best score, streak |
| 🌑 Dark UI | Full dark-mode design with purple-gradient theme |

## 🔧 Setup (3 steps)

### 1 — Supabase

1. Go to [supabase.com](https://supabase.com) and create a free project.
2. In the **SQL Editor**, run:

```sql
-- profiles table
CREATE TABLE profiles (
  id          UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username    TEXT NOT NULL,
  email       TEXT NOT NULL,
  total_quizzes INT DEFAULT 0,
  best_score  INT DEFAULT 0,
  avg_accuracy FLOAT DEFAULT 0,
  streak      INT DEFAULT 0,
  created_at  TIMESTAMPTZ DEFAULT now()
);

-- Row Level Security
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can read all profiles"  ON profiles FOR SELECT USING (true);
CREATE POLICY "Users can update own profile" ON profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Users can insert own profile" ON profiles FOR INSERT WITH CHECK (auth.uid() = id);
```

3. From **Project Settings → API**, copy:
   - **Project URL** → paste as `SUPABASE_URL`
   - **anon / public** key → paste as `SUPABASE_ANON_KEY`

### 2 — Android Studio

Open `app/src/main/java/com/quizmaster/utils/SupabaseManager.java` and replace:

```java
private static final String SUPABASE_URL     = "https://YOUR_PROJECT_ID.supabase.co";
private static final String SUPABASE_ANON_KEY = "YOUR_ANON_KEY_HERE";
```

### 3 — Build

Open the project folder in **Android Studio Hedgehog or newer**, let Gradle sync, then **Run ▶**.

## 📦 Tech Stack

- **Retrofit 2** — API calls to OpenTDB (free trivia questions)
- **OkHttp 4** — Supabase REST calls (no Kotlin SDK = pure Java)
- **Gson** — JSON parsing
- **Material Components** — modern UI widgets
- **Supabase** — auth + PostgreSQL leaderboard

## 📁 Project Structure

```
app/src/main/java/com/quizmaster/
├── activities/      SplashActivity, LoginActivity, RegisterActivity,
│                    HomeActivity, CategoryActivity, QuizSetupActivity,
│                    QuizActivity, ResultActivity, LeaderboardActivity,
│                    ProfileActivity
├── adapters/        CategoryAdapter, LeaderboardAdapter
├── models/          Category, Question, QuizResponse, UserProfile,
│                    LeaderboardEntry, QuizResult
├── network/         TriviaApi, RetrofitClient
└── utils/           SupabaseManager (auth + stats + leaderboard)
```

---
Built with ❤️ — ready to run after adding your Supabase credentials.
